# Readers

| Reader | Reads it for | Question they always ask | Format notes |
|---|---|---|---|
| **{{primary reader}}** | {{why they read it}} | {{"Is anything going to surprise me?"}} | {{from their team file}} |
| {{other reader}} | | | |
