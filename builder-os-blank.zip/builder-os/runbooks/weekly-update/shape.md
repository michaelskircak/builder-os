# Shape

Edit this to match what your readers expect. Starter version:

```
Subject: {{area}} · week of {Mon DD}

{Headline: one or two sentences. The thing they need if they read nothing else.}

**Moved**
- {progress, named people, a number}

**Stuck / at risk**
- {issue} → {what I'm doing} → {what I need, from whom, by when}

**Next week**
- {2 or 3 things}

| Project | Status | One line |
|---|---|---|

{{sign-off}}
```
