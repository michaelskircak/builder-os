# Steps

## 1 · gather
Create `drafts/YYYY-MM-DD/`. Pull from every source in `sources.md` that's available. Write it all to `drafts/YYYY-MM-DD/raw.md` as plain bullets grouped by project, source next to each.

**Checkpoint:** Show the raw list and ask:
- "Which 2 or 3 of these does {{primary reader}} need to know?"
- "Anything that happened that isn't in the files?"
- "Did any project's status change?"

Save the answers at the bottom of `raw.md` under `## Picks`.

## 2 · draft
Read `raw.md`, `readers.md`, `shape.md`, and the last two files in `sent/`. Write `drafts/YYYY-MM-DD/draft.md`.

**Checkpoint:** "Anything wrong, missing, or too soft?"

## 3 · polish
Apply `context/voice.md`. For each reader in `readers.md`, check the draft answers the question they always ask. Add `<!-- polished -->` at the top.

**Checkpoint:** Show the final and the biggest edits.

## 4 · send
The user sends it. After they say "sent":
- Copy to `sent/YYYY-MM-DD.md`
- Add "Weekly weekly update sent" to `memory/done/YYYY-MM.md`
- Check off the weekly update commitment in `SPRINT.md`
