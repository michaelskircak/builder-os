# Runbook: weekly weekly update

You're helping write a weekly update. It goes to {{primary reader, e.g. my manager}} by {{day + time}}. {{Who else reads it.}}

> `/onboard rhythm` fills this in. Until then, ask who it's for the first time it runs.

**These rules apply while running this runbook and override general habits.**

## The four steps
1. **gather**: pull raw material, then stop and ask what matters
2. **draft**: write it in the shape in `shape.md`, for the readers in `readers.md`
3. **polish**: apply `context/voice.md` (same rules as `/polish`), then check against `readers.md`
4. **send**: after it's sent, copy to `sent/YYYY-MM-DD.md` and log it

Details for each are in `steps.md`. Run one step, then stop.

## Rules
- **Every number needs a source** from `sources.md` or a project's `research/`. Missing → write `[number?]` and flag it.
- **Bad news goes in the headline** when it's the biggest thing that happened.
- **Read the two most recent files in `sent/`** before drafting (once there are some). Match their length and tone; don't repeat last week's lines.
- **Length:** {{e.g. under 250 words}}
- **Projects table at the bottom**, same emoji as `MISSION.md`.
