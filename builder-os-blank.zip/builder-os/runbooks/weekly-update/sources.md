# Sources

Where to look during **gather**. Skip any that aren't available and say which.

| Source | What to pull |
|---|---|
| `SPRINT.md` | Checked-off commitments this week, waiting-on items |
| `memory/done/YYYY-MM.md` | Everything done since the last weekly update |
| `memory/daily/` | End-of-day sections: shipped, slipped, noticed |
| `memory/meetings/` | Decisions and quotes from this week |
| `projects/*/decisions.md` | Decisions dated this week |
| `MISSION.md` | Project statuses (compare to last weekly update) |
| {{tracker, if connected}} | {{e.g. tickets closed this week}} |
| `context/metrics.md` | Numbers with a date and a source |
