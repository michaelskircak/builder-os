# Runbooks

A runbook is repeat work with more than one step, its own reference files, and rules that only apply while you're running it. Each has a `CLAUDE.md` that Claude reads first.

Projects end; runbooks repeat. If you've done something by hand three times, run `/new-skill` and turn it into one. `/onboard pack` suggests runbooks for your role.

| Runbook | Command | Runs | Added |
|---|---|---|---|
| [weekly-update](weekly-update/) | `/weekly` | {{weekly, e.g. Fridays}} | {{date}} |
