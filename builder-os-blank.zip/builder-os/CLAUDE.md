# Builder OS · {{Your name}}

> Not set up yet? Run `/onboard`. It fills in this file and everything it points to.

I'm **{{name}}**, {{title}} at **{{company}}** ({{one line on what the company does}}). I own **{{what you're responsible for}}**. I report to **{{manager}}**.

## Where things live
- `MISSION.md`: what I own, this quarter's projects, my team at a glance
- `SPRINT.md`: this week. Commitments, waiting-on, parked. `BACKLOG.md`: everything else
- `projects/`: one folder per initiative. Start at its `README.md`; calls go in `decisions.md`
- `team/`: one file per person I work with: teammates, execs, customers, partners
- `memory/`: `daily/`, `meetings/`, `1on1s/`, `done/`
- `runbooks/`: repeatable multi-step work, each with its own `CLAUDE.md`
- `context/`: company, product, customers, glossary, metrics, and `voice.md` (how I write)
- `templates/`: starting points for new files. `inbox/`: dump anything
- `CONFIG.md`: what's connected + conventions. `CHANGELOG.md`: how this OS has changed

## My week
{{Recurring meetings, rituals, deadlines. Filled by /onboard rhythm.}}

## Commands
| Command | Does |
|---|---|
| `/onboard` | Interview-based setup (re-run a section any time) |
| `/brief` | Morning brief: calendar + sprint + projects + team |
| `/prep <person>` | Meeting prep in that person's preferred format |
| `/debrief` | Paste notes → files commitments, quotes, decisions |
| `/eod` | End of day: update the sprint, log it, set up tomorrow |
| `/new-project <name>` | Start a new project folder |
| `/research <project>` | Turn raw research into findings with quotes and counts |
| `/decide <question>` | Write a decision record into the project |
| `/capture` · `/capture sort` | Dump to inbox · route the inbox |
| `/weekly` | Weekly update runbook, one step at a time |
| `/polish <file>` | Make a draft sound like me |
| `/cleanup` | Weekly cleanup |
| `/handoff out` · `/handoff in` | Package a project for the build · file what the build sent back |
| `/new-skill` | Turn repeat work into a new command |

## House rules
- Never invent quotes, numbers, or dates. If it isn't in a file, say so.
- Dates are `YYYY-MM-DD`. File names are `kebab-case`.
- When you learn something lasting about a person, offer to add it to their team file.
- Anything I'll send to another human goes through `context/voice.md`.
- If a file still has `{{placeholders}}` and it matters for the task, ask me or suggest `/onboard <section>`.
