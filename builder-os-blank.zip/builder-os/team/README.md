# Team

One file per person you work with: manager, teammates, execs, partners, customers. `/onboard team` creates the first batch; `/debrief` keeps them current.

Format is in `templates/team-member.md`. The two lines that matter most:
- **How to work with them** (best format, channel, what they hate)
- **What they care about**

Everything `/prep` and `/weekly` write gets shaped by these files. Ten minutes per person pays back every meeting.

Name files `first-last.md`.
