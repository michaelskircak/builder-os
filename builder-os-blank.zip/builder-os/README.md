# Builder OS

A folder that makes Claude Code know your job.

## Start here (15 minutes)

1. Unzip this folder somewhere you'll keep it (Documents, Dropbox, a git repo).
2. Open a terminal in the folder and run `claude`.
3. Type **`/onboard`**.

Claude interviews you about your role, what you own, who you work with, how your week runs, which tools you use, and how you write. It writes the files as you go. Stop any time and pick up a section later with `/onboard team`, `/onboard voice`, and so on.

Works for any role that ships things with other people: PMs, engineers, designers, founders, marketers, ops, sales, support, data. At the end, `/onboard` suggests a **role pack**: runbooks built for your kind of repeat work.

## Every day

```
/brief              morning: what today is actually about
/prep <person>      before a meeting
/debrief            after a meeting: paste notes, everything gets filed
/eod                end of day, 2 minutes
```

## Projects

```
/new-project <name> start a project folder
/research <project> turn interviews, tickets, and data into findings with quotes
/decide <question>  write down a decision before everyone forgets why
/handoff out <p>    package a project for your build pipeline · /handoff in to sync back
```

## Anytime

```
/capture <thing>    dump anything in inbox/ · /capture sort to route it
/weekly             weekly update, one step at a time
/polish <file>      make a draft sound like you
/cleanup            weekly cleanup
/new-skill          turn repeat work into your own command
```

## How it's organized

```
CLAUDE.md       who you are + map of the folder (Claude reads it first)
MISSION.md      what you own, this quarter's projects, your team at a glance
SPRINT.md       this week · BACKLOG.md: everything else
projects/       one folder per project: README.md, decisions.md, research/, artifacts/
team/           one file per person you work with
memory/         daily/, meetings/, 1on1s/, done/
runbooks/       repeat work with its own rules
context/        company, product, customers, glossary, metrics, voice
templates/      starting points for new files
inbox/          dump anything
CONFIG.md       what's connected · CHANGELOG.md: how your OS has changed
```

No connections required. Calendar, tracker, and docs connections make `/brief` and `/weekly` richer, but every command falls back to the files.

Want to see a fully filled-in version first? Download the Builder OS example: a PM at a bill-splitting app in the middle of a very bad week.
