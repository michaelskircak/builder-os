---
name: debrief
description: After a meeting, turn messy notes or a transcript into a clean meeting note, then file everything that came out of it - my commitments, their commitments, new facts about people, customer quotes, and decisions that need making. Use when the user pastes meeting notes, says debrief, "just got off a call", or "file this".
argument-hint: "[meeting name or person] then paste notes"
---

# /debrief

I'll paste raw notes, a transcript, or a voice memo dump. Your job is to make sure nothing in it gets lost and nothing gets made up.

## 1. Find the meeting file

- If `/prep` ran for this meeting today, there's a file in `memory/meetings/` with a `## Prep` section. Add a `## Notes` section to that file.
- Otherwise create `memory/meetings/YYYY-MM-DD-<slug>.md` from `templates/meeting.md`.
- For a recurring 1:1, also append a dated entry to `memory/1on1s/<name>.md`.

## 2. Clean the notes

Keep the substance and their words. Fix typos, group by topic, and keep direct quotes in quotes. Don't summarize away a specific number, date, or name.

## 3. File the outputs

| What you find | Where it goes |
|---|---|
| Something **I** committed to | `SPRINT.md` → Commitments, with who it's for and a due date (ask if none was said) |
| Something **they** committed to | `SPRINT.md` → Waiting on, with today's date as the start |
| Something new about **how a person works** (preference, pet peeve, context) | Their `team/` file → "Notes over time", dated, in their words where possible |
| A **customer or user quote** that's evidence for a project | Copy into `projects/<project>/research/` (append to the matching interview or a dated `field-notes.md`) |
| A **decision** that got made in the room | `projects/<project>/decisions.md` using `templates/decision.md`, marked "Decided in meeting" |
| A decision that **still needs making** | Don't make it. List it and suggest `/decide` |
| Anything else useful later | `inbox/` |

## 4. Show me the receipt

End with a short table of every file you touched and what changed, so I can eyeball it in 10 seconds:

```
Filed:
- SPRINT.md: +2 commitments, +1 waiting-on
- team/gus-ferreira.md: +1 note, open loops updated
- projects/rise-pro/research/field-notes.md: +3 quotes
Needs a call: "Do we delay v2?" → /decide
```

## Rules

- Never put words in anyone's mouth. If the notes are ambiguous about who said something, mark it `(unclear who)`.
- Never edit `MISSION.md` from a debrief without asking.
- If the notes mention someone with no team file, ask whether to create one.
