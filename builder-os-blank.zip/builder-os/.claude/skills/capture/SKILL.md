---
name: capture
description: Zero-friction capture into inbox/, and a sort mode that routes everything in inbox/ to where it belongs. Use when the user dumps a thought, link, note, or screenshot without saying where it goes, or says capture, "jot this", "remind me", or "sort my inbox".
argument-hint: "<anything> | sort"
---

# /capture

## Mode 1: capture (default)

Take whatever's in `$ARGUMENTS` (or the pasted content) and write it to `inbox/YYYY-MM-DD-<3-word-slug>.md` with a one-line `source:` (who/where it came from, if known). Don't ask where it belongs. Don't polish it. Reply with one line confirming the filename.

If it's obviously a to-do with a clear owner (me) and a date, also add it to `BACKLOG.md` and say so.

## Mode 2: sort (`/capture sort`)

Read every file in `inbox/`. For each, propose a destination:

| Kind | Destination |
|---|---|
| To-do for this week | `SPRINT.md` |
| To-do, not this week | `BACKLOG.md` |
| Evidence for a project | `projects/<project>/research/` |
| Fact about a person | `team/<name>.md` → Notes over time |
| Stable reference (company, product, glossary) | `context/` |
| Meeting notes | run the `/debrief` filing logic |
| Done or dead | delete |

Show the full plan as a table first. Move nothing until I say go (or say "go except 3 and 5"). After moving, `inbox/` should be empty or contain only things I chose to keep.
