---
name: weekly
description: Run the weekly-update runbook - the weekly update to your manager, team, or stakeholders - in four steps with a human checkpoint after each. Use when the user says weekly, weekly update, status update, "write my Friday update", or names a step (gather, draft, polish, send).
argument-hint: "[gather | draft | polish | send]"
---

# /weekly $ARGUMENTS

This command is a front door. The runbook lives in `runbooks/weekly-update/`.

1. Read `runbooks/weekly-update/CLAUDE.md` and follow it. It overrides general habits for the length of this task.
2. Figure out which step to run:
   - If `$ARGUMENTS` names a step, run that step.
   - Otherwise look in `runbooks/weekly-update/drafts/` for this week's folder (`YYYY-MM-DD` of the Friday). No folder → `gather`. Has `raw.md` but no `draft.md` → `draft`. Has `draft.md` without a "polished" marker → `polish`. Polished → `send`.
3. Run only that one step, then stop at its checkpoint and wait for me.

Never run all four steps in one go. The checkpoints are the point.
