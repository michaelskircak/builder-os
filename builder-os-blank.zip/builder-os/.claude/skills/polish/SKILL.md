---
name: polish
description: Rewrite a draft so it sounds like the user wrote it, not a model. Applies context/voice.md, strips AI tells, keeps every fact identical. Use when the user says polish, humanize, "edit this", "make this sound like me", "de-AI this", or before anything gets sent to people.
argument-hint: "<path to file> (or paste text)"
---

# /polish $ARGUMENTS

## 1. Load the voice

Read `context/voice.md`. It has the user's banned words, their sentence habits, and a few samples of things they've actually written. If it doesn't exist, use the defaults below and suggest running `/onboard voice`.

## 2. Rewrite

Default fixes (voice.md overrides these):

- **Cut throat-clearing.** "I wanted to provide a quick update on" → start with the update.
- **Swap inflated verbs.** leverage, utilize, facilitate, streamline, empower, enhance, delve → use, run, help, cut, let, improve, look at. Or rewrite the sentence.
- **Kill hedges and filler.** "It's important to note that", "In order to", "Moving forward", "At the end of the day".
- **Break the rhythm.** If every bullet is the same length, make some short. If three sentences in a row are the same length, merge two.
- **Break the threes.** Models list things in threes. Use two, or four, or one.
- **Name things.** "Several customers" → "Acme and Northwind" if the source names them.
- **Contractions.** "do not" → "don't" unless it's emphasis.
- **Fewer em dashes.** Use a period, a comma, or a colon.

## 3. Hard rules

- Don't add facts, numbers, praise, or apologies that weren't there.
- Don't remove a number, date, owner, or ask.
- Keep the structure if the structure is the format the reader asked for.

## 4. Show your work

Write the new version back to the file (or reply with it if text was pasted). Then show up to 8 of the biggest before → after changes so I can see what moved.
