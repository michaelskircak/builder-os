---
name: brief
description: Morning brief. Reads SPRINT.md, MISSION.md, yesterday's end-of-day notes, today's calendar and tracker (if connected), and the team file of everyone you're meeting, then tells you what today is actually about. Use when the user says brief, morning, standup, "what's today look like", or "what should I focus on".
argument-hint: "[optional: tomorrow | YYYY-MM-DD]"
---

# /brief

Tell me what today is about before I open Slack. Default to today; if `$ARGUMENTS` says `tomorrow` or gives a date, brief that day instead.

## Read, in this order

1. `SPRINT.md`: focus line, commitments (with due dates), waiting-on (with how long), parked.
2. `MISSION.md`: the projects section only. Note any project marked 🔴 or 🟡.
3. The newest file in `memory/daily/`. If it has a `## End of day` section, its "Carry forward" list is yesterday's promise to today.
4. **Calendar.** If a calendar connector is available (check `CONFIG.md` → Connections), pull the day's events. If not, say "Calendar isn't connected" once and move on; don't ask me to paste it unless I offered.
5. **Tracker.** If a tracker connector is listed in `CONFIG.md`, pull items assigned to me, items that changed since the last brief, and anything flagged blocked. If not, `SPRINT.md` is the source of truth.
6. **People.** For every meeting attendee, look for `team/<first-last>.md`. Pull one line from "How to work with them" and any "Open loops" that involve me.

## Then connect the dots

This is the part that earns the command. Look for:

- A meeting today with someone I'm waiting on → say so next to the meeting.
- A commitment due today or overdue → it goes near the top.
- A waiting-on item older than 3 working days → flag it as stuck.
- A project at 🔴 with nothing on today's calendar touching it → call that out.
- Anything in yesterday's "Carry forward" that didn't make it into `SPRINT.md`.

## Output

```
# Brief · {Weekday, Mon DD}

**The one thing:** {single sentence: the thing that makes today a win}

## Calendar
- {time} · {meeting} · {who} → {why it matters today / what to bring}

## Due or overdue
- {commitment} · {to whom} · {due}

## Stuck
- {waiting-on} · {days waiting} · {how to unstick it}

## Projects at risk
- {project} {status} · {one line}

## Order of attack
1. ...
2. ...
```

Then save the same text under a `## Brief` heading in `memory/daily/YYYY-MM-DD.md` (create it from `templates/daily.md` if it doesn't exist).

## Rules

- 250 words max on screen. A brief is a brief.
- Lead with the one thing. Never open with a greeting or a pep talk.
- If a section is empty, drop it. Don't write "None".
- Don't invent meetings, tickets, or numbers. If a source is missing, work with what exists.
