---
name: cleanup
description: Weekly maintenance so the OS doesn't rot. Sweeps inbox, flags stale commitments and projects, finds team files that need refreshing before upcoming meetings, and dedupes BACKLOG.md. Use when the user says tidy, weekly review, "clean up", or on Fridays.
---

# /cleanup

Run through this list and report back as one checklist. Don't change anything until I approve each group.

1. **Inbox.** How many files are in `inbox/`? If more than zero, offer to run `/capture sort`.
2. **SPRINT.md.** Any commitment older than 14 days? For each: do it this week, move to `BACKLOG.md`, or kill it.
3. **Waiting on.** Anything 🧊 (over 5 working days)? Draft a one-line nudge for each, in the style that person's team file prefers.
4. **Projects.** For each project in `MISSION.md`: when was the last entry in its `decisions.md` or the last file change? Flag any project with no movement in 3 weeks. Does its status emoji still match reality?
5. **Team.** Team files not updated in 60 days for people I've met recently (check `memory/meetings/`). Suggest one thing to add from recent meeting notes.
6. **BACKLOG.md.** Duplicates, items that are already done, items that belong in a project.
7. **Skills.** Scan `memory/daily/` from the last two weeks for any task I did 3 or more times by hand. If you find one, suggest `/new-skill` for it.

End with a one-line health score: "{n} things tidied, {n} need you."
