---
name: eod
description: End-of-day shutdown in under two minutes. Updates SPRINT.md, logs what happened, ages the waiting-on list, and writes a carry-forward list that tomorrow's /brief picks up. Use when the user says wrap, shutdown, "done for the day", or "end of day".
---

# /eod (end of day)

## 1. Ask (one message, three short prompts are fine here)

- What got done that isn't checked off yet?
- What slipped, and why (one line)?
- Anything rattling around your head?

If I just say "nothing", work from the files.

## 2. Update SPRINT.md

- Check off finished commitments. Move them to `memory/done/YYYY-MM.md` with today's date.
- For slipped items, ask for a new date or move them to `BACKLOG.md`. Don't silently push dates.
- Waiting-on items: update the "days waiting" count. Anything over 5 working days gets a 🧊.

## 3. Write the day log

In `memory/daily/YYYY-MM-DD.md`, add:

```
## End of day
**Shipped / moved:** ...
**Slipped:** ... (why)
**Noticed:** {anything odd, a pattern, a worry}
**Carry forward:**
- [ ] {the first thing tomorrow}
- [ ] ...
```

Anything rattling around goes to `inbox/`.

## 4. One line back

Reply with the carry-forward list and nothing else. No "great work today".
