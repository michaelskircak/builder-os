---
name: new-skill
description: Mod the OS. Turns a task the user keeps doing by hand into a new slash command (a skill) or a multi-step runbook, wires it into CLAUDE.md, and test-runs it on real files. Use when the user says make a skill, "turn this into a command", "I keep doing this", "mod", or after /cleanup spots repeated work.
argument-hint: "<what you keep doing> | scan"
---

# /new-skill $ARGUMENTS

Builder OS ships with a starter set of commands. The ones that end up mattering most are the ones you build yourself, because they encode how *you* work.

## 0. Scan mode (`/new-skill scan`)

Read `memory/daily/` and `memory/meetings/` from the last three weeks. List up to five tasks that show up repeatedly (same shape of work, same inputs). For each: how many times, which files it touched, rough time it took. Ask which one to build.

## 1. Interview

Ask, briefly:

1. **Trigger.** When do you reach for this? What would you type?
2. **Inputs.** Which files or folders does it need? Any connector (calendar, tracker, email, docs)?
3. **Steps.** Walk me through the last time you did it by hand.
4. **Output.** What does good look like? Paste a past example if you have one.
5. **Where it lands.** Which file gets written or updated?
6. **Checkpoints.** Where do you want to review before it continues?

## 2. Skill or runbook?

- **Skill** (`.claude/skills/<name>/SKILL.md`): one sitting, one output, no special reference files. Most things.
- **Runbook** (`runbooks/<name>/` + a thin skill that points to it): multiple steps with checkpoints, its own reference files (templates, examples, rules, past outputs), or behavior that should differ from the rest of the OS. Give the runbook its own `CLAUDE.md` so those rules only apply inside it.

## 3. Write it

A good Builder OS skill:

- Has a `description` that says what it does **and** the phrases that should trigger it.
- **Points to files instead of pasting their content.** The skill says "read `team/<name>.md`"; the knowledge lives in the folder.
- **Degrades gracefully.** If a connector isn't there, it says so in one line and uses files.
- **Writes its output to a file**, so the next command can build on it.
- States its rules in plain language at the bottom: length limits, what never to invent.
- Uses `$ARGUMENTS` for whatever the user types after the command.

Frontmatter:

```
---
name: <kebab-name>
description: <what it does>. Use when the user says <triggers>.
argument-hint: "<what to type after the command>"
---
```

## 4. Wire it in

- Add a row to the commands table in the root `CLAUDE.md`.
- If it's a runbook, add a line to `runbooks/README.md`.
- If it needs a template, add it to `templates/`.

## 5. Test it on something real

Run the new command once against real files in this OS. Show me the output. Ask what to change, edit the skill, and run it again. Two rounds is normal.

## 6. Log it

Add a dated line to `CHANGELOG.md`: "Added /<name>: <one line>".
