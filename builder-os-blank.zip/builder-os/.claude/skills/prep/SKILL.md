---
name: prep
description: Prep for a meeting with a person or group. Loads their team file, past meeting notes, open loops, related projects and decisions, then writes talking points in the format that person prefers. Use when the user says prep, "get me ready for", or names an upcoming meeting.
argument-hint: "<person-name | meeting-name>"
---

# /prep $ARGUMENTS

## 1. Find who this is

- Look for `team/$ARGUMENTS.md`. If there's no exact match, try first name, last name, company, and the `aka:` line inside team files. If two match, ask which.
- If it's a group meeting (no single team file), find each attendee's file and prep for the room.
- If nobody matches, say so and offer to create a team file from `templates/team-member.md` after the meeting.

## 2. Load history

- Running notes: `memory/1on1s/<name>.md` if it exists.
- Past meetings: search `memory/meetings/` for their name. Read the newest 3.
- Their team file's "Open loops" (both directions: what I owe them, what they owe me).
- `SPRINT.md`: any commitment or waiting-on that names them.
- `projects/*/decisions.md`: any decision that lists them under "Who needs to know" and hasn't been marked as told.

## 3. Load what they care about

From their team file: "What they care about" and "How to work with them". If they care about a metric, find the current number in `MISSION.md` or the relevant project. Never guess a number; write `{number: check X}` if it isn't in the files.

## 4. Write the prep

Match their preferred format. If the team file says "bottom line first", the first line is the bottom line. If it says "talks in stories, not dashboards", lead with what happened.

```
# Prep · {name} · {date}

**Goal of this meeting:** {one sentence; what does "this went well" look like}

## Open with
{the first thing I say, in their format}

## They'll probably ask
- {question} → {my answer, with the source file}

## My asks
- {what I need from them, specific}

## Open loops
- I owe: ...
- They owe: ...

## Careful
- {landmines: sensitive topics, past friction, things they've said they hate}
```

Save it as `memory/meetings/YYYY-MM-DD-<slug>.md` under `## Prep`, so `/debrief` can add notes to the same file later.

## Rules

- Under 300 words. I'm reading this in the hallway.
- Every claim about the past points to the file it came from.
- "Careful" only contains things the files actually say. No armchair psychology.
