---
name: new-project
description: Start a new project (feature, initiative, experiment, campaign, deal, launch) by interviewing the user and scaffolding a projects/ folder with README.md, decisions.md, research/ and artifacts/. Use when the user says new project, new initiative, "I'm starting work on", or describes a new initiative.
argument-hint: "<short name>"
---

# /new-project $ARGUMENTS

A project is any piece of work big enough that you'd lose context if you stopped for a week. Product feature, campaign, hiring push, migration, sales deal; doesn't matter.

## 1. Interview (keep it quick)

Ask these one or two at a time, conversationally. Skip any I've already answered.

1. What's the problem, and who has it? (Push for a specific person or moment, not a category.)
2. Why now? What changed?
3. What does done look like? One number or observable outcome if possible.
4. Appetite: how much time is this worth before we stop and reassess?
5. What would make us kill it early?
6. Who's involved, and who needs to be kept in the loop?
7. What do we believe that we haven't proven yet? (These become the assumptions `/research` checks.)

## 2. Scaffold

```
projects/<slug>/
├── README.md        ← from templates/project.md, filled with the answers
├── decisions.md    ← empty log with a header
├── research/       ← raw research lands here
└── artifacts/      ← specs, drafts, decks, anything we make
```

## 3. Register it

- Add the project to the projects table in `MISSION.md` with status ⚪ (not started) or 🟢.
- If anyone named in step 6 has no team file, offer to create one.
- Add the first concrete next step to `SPRINT.md`.

Close with one sentence: "Point me at `projects/<slug>/` any time and I'll have the context."
