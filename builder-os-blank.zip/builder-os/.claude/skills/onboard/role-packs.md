# Role Packs

Builder OS works the same for everyone at the core: MISSION, SPRINT, projects, team, memory. What changes by role is the repeat work. Each pack below lists runbooks and commands worth building with `/new-skill`. Suggest the ones that match what the person said they do on repeat; don't install a whole pack blind.

Each entry: **name** · trigger · what it reads → what it writes.

---

## Product manager

- **problem-brief** · built in: `/handoff out <project>` packages the problem, evidence, and decisions for whatever turns it into a spec and code. `/handoff in` files what comes back.
- **launch-checklist** (runbook) · "we're launching X" · project folder, `team/` (who needs to know) → a dated checklist with owners for eng, design, support, sales, legal, docs.
- **roadmap-narrative** · "explain the roadmap to {person}" · `MISSION.md`, projects, that person's team file → a one-page story in their format.
- **interview-guide** · "I'm talking to users about X" · `README.md` assumptions → questions that test each assumption without leading.

## Engineer / tech lead

- **tech-debt-log** · "log this debt" · a note or PR → `projects/tech-debt/research/` entry with cost, risk, and when it'll bite.
- **incident-review** (runbook) · "write the postmortem" · pasted timeline, logs, Slack → blameless review with timeline, contributing factors, follow-ups added to `SPRINT.md`.
- **pr-story** · "explain this change" · a diff or PR link → reviewer-friendly summary: why, what, risk, how to test.
- **oncall-handoff** · "end of my on-call" · `memory/daily/` for the week → handoff note: open issues, flaky things, what to watch.

## Designer

- **critique-prep** · "prep for crit" · project folder, evidence, team files of attendees → what feedback to ask for and from whom.
- **design-rationale** · "why did we design it this way" · `decisions.md`, evidence → a rationale doc that cites research for each choice.
- **usability-synthesis** · use `/research` with a template tuned for task success, errors, and quotes per task.
- **handoff-notes** · "ready for eng" · artifacts → edge cases, states, copy, and open questions for engineering.

## Founder / operator

- **investor-update** (runbook) · "monthly update" · `MISSION.md`, `memory/done/`, metrics → highlights, lowlights, numbers, asks. Lowlights are mandatory.
- **hiring-loop** (runbook) · "hiring for X" · a project per role: scorecard, interview plan, candidate notes in `research/`, decisions in `decisions.md`.
- **board-prep** · "board meeting" · projects, decisions, metrics → narrative + the three questions the board will ask.
- **weekly-ceo-note** · use `/weekly` with readers set to the whole company.

## Marketing / growth / content

- **campaign-brief** · "new campaign" · `/new-project` with campaign fields: audience, message, channels, budget, success metric.
- **content-calendar** (runbook) · "plan next month" · `MISSION.md`, past performance in `research/` → calendar with owners and dates.
- **experiment-readout** · "how did the test do" · pasted results → result, confidence, what we learned, next test. Logged to `decisions.md`.
- **launch-copy** · "write the launch post" · project folder + `context/voice.md` → drafts, then `/polish`.

## Sales / customer success / partnerships

- **account-prep** · use `/prep` with the account's team files + `projects/<account>/` per big deal or account.
- **qbr** (runbook) · "QBR for {account}" · account project folder, usage numbers, open tickets → business review deck outline.
- **deal-review** · "where's this deal" · account folder → stage, champion, blockers, next step, risk.
- **customer-incident** (runbook) · "a customer got burned" · incident notes, team file → acknowledgment, timeline, make-good, follow-up schedule.

## Program / project / ops manager

- **status-rollup** · use `/weekly` with sources set to every team's tracker.
- **raid-log** · "update the RAID" · projects and meetings → risks, assumptions, issues, dependencies, each with an owner.
- **dependency-check** · "what's blocking what" · `SPRINT.md` waiting-on across projects → dependency map and the one unblock that frees the most work.
- **retro** (runbook) · "run a retro" · `memory/` for the sprint → what happened, patterns, two changes to try.

## Data / analytics / research

- **analysis-brief** · "someone asked for numbers" · request → question, decision it informs, data needed, deadline. Prevents dashboard-for-nobody work.
- **findings-memo** · "write up the analysis" · results → headline, method, caveats, recommendation, in the reader's team-file format.
- **metric-definitions** · "what does X mean" · maintains `context/metrics.md` as the single source of truth.
- **research-repo** · use `/research` across projects to find patterns that span projects.

---

Not on the list? Ask what they produce on repeat, and build those.
