---
name: onboard
description: Set up Builder OS for a new user by interviewing them about their role, what they own, who they work with, their weekly rhythm, tools, and writing voice, then writing the files. Works for any role. Re-run a single section with /onboard <section>. Use when the user says onboard, set up, "get started", or the OS still has unfilled placeholders.
argument-hint: "[all | me | goals | team | rhythm | tools | voice | pack]"
---

# /onboard $ARGUMENTS

You're setting up someone's operating system. Be a sharp, friendly interviewer, not a form. The person should finish this feeling like you understood their job.

## Ground rules

- **Ask one or two questions at a time.** Never dump a questionnaire.
- **Write as you go.** After each section, write the files for it and show a 3-line summary of what you wrote. If the session dies halfway, nothing is lost.
- **Use their words.** If they say "my pod" instead of "my team", the files say "my pod".
- **Never invent.** If they skip something, leave the `{{placeholder}}` in place and add it to the "Still to fill" list at the end.
- **Let them paste.** Offer at each step: "If it's easier, paste your LinkedIn about section / your team's wiki page / last quarter's goals doc and I'll pull from it."
- **Check for connectors** (calendar, tracker, email, docs, chat) before asking about tools. If one is available, offer to read from it: e.g. "I can see your calendar. Want me to pull who you meet with most this month instead of you listing them?"

If `$ARGUMENTS` names a section, run only that section. Otherwise run them in order, and tell the user up front: "About 15 minutes, seven short sections. You can stop any time and pick up with `/onboard <section>`."

---

## Section 1 · me → `CLAUDE.md` (Who I am), `MISSION.md` (Me)

Ask:
- Name, title, company, and what the company does in one sentence.
- "If a new teammate asked what you actually do all day, what would you say?"
- Which of these is closest: builds the thing / decides what gets built / helps people use the thing / sells the thing / runs the machine that does all of the above / something else? (This picks the role pack in Section 7. Don't show the list as labels; read their answer.)
- How long they've been in the role.

## Section 2 · goals → `MISSION.md`

Ask:
- What are you on the hook for this quarter (or half, or year; use their planning cycle)? Push for numbers or observable outcomes.
- What's the biggest thing you're working on right now? → this becomes their first project. Offer to run `/new-project` for it at the end.
- What are you explicitly *not* doing? (Non-goals are underrated.)
- What would make this quarter a win, in one sentence?

Write the projects table with status emojis: 🟢 on track, 🟡 at risk, 🔴 off track, ⚪ not started.

## Section 3 · team → `team/*.md`

Say: "Now the people. The better I know them, the better every prep and update gets."

- Who's your manager? Who do you work with every week? Any customers, clients, or partners you talk to regularly?
- Aim for 4 to 8 people. Their manager first.
- For each person, ask two things (more only if they're enthusiastic): **How do they like to get information?** and **What do they care about most?** Optional third: anything that annoys them.
- Write each to `team/<first-last>.md` from `templates/team-member.md`. Add a row to the team table in `MISSION.md`.
- Create `memory/1on1s/<name>.md` for anyone they have a recurring 1:1 with.

## Section 4 · rhythm → `SPRINT.md`, `CLAUDE.md` (My week)

Ask:
- What does a normal week look like? Recurring meetings, rituals, deadlines (standup, planning, Friday update, monthly business review, pipeline review, on-call).
- What do you produce on repeat? (Weekly update, release notes, reports, proposals, campaign briefs, PR reviews.) Each repeat task is a candidate runbook.
- What are you doing this week? What are you waiting on from other people? → seed `SPRINT.md`.
- Anything nagging that isn't this week? → seed `BACKLOG.md`.

## Section 5 · tools → `CONFIG.md`

- Where do tasks/tickets live? Docs? Chat? Calendar? Email? Analytics or CRM?
- Mark each as **connected** (a connector is available in this session), **could connect** (they use it, no connector yet), or **files only**.
- Explain once: "Everything works without connectors. They just let /brief and /weekly pull live data."

## Section 6 · voice → `context/voice.md`

- "Paste two or three things you've written that sound like you: a Slack message, an update, an email you were happy with."
- Read the samples and write down what you notice: sentence length, formality, how they open, how they sign off, emoji use, words they use a lot.
- Ask: any words or phrases you hate? Any you overuse?
- Write `context/voice.md`. Show them the 5 most important rules you extracted and ask if they're right.

## Section 7 · pack → `runbooks/` and suggestions

Read `role-packs.md` (next to this file). Pick the pack that best matches Section 1. Then:

- Tell them which 2 to 4 runbooks or commands from the pack fit what they said in Section 4. Explain each in one line, using their own recurring work as the example.
- Ask which they want. Build the chosen ones with the `/new-skill` process (runbook or skill).
- If their role isn't in the file, build a custom pack from Section 4's repeat work.

---

## Finish

1. Fill `context/company.md` and `context/product.md` from anything they shared. Leave placeholders where they didn't.
2. Write `memory/daily/<today>.md` with a note: "Onboarded Builder OS."
3. Show a summary:

```
Builder OS is set up.
- North star: {one line}
- Projects: {n}   Team: {n}   Runbooks: {list}
- Still to fill: {placeholders left, by file}

Try these next:
1. /brief          ← tomorrow morning
2. /prep {their manager's name}
3. /new-project {their biggest thing}
```

4. Add a dated line to `CHANGELOG.md`.
