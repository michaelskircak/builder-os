---
name: decide
description: Turn an open question into a written decision record - context, real options with costs, the call, why, who needs to know, and when to revisit. Appends to the project's decisions.md. Use when the user says decide, "we need to make a call", "should we X or Y", or a debrief flags an open decision.
argument-hint: "<the question>"
---

# /decide $ARGUMENTS

Decisions are the thing teams forget fastest. Three weeks later someone asks "why did we do it this way?" and nobody remembers. This command makes the answer a file.

## 1. Find the project

Match the question to a folder in `projects/`. If it spans two, pick the one it affects most and link the other. If it isn't tied to a project, use `memory/decisions.md`.

## 2. Load context

- The project's `README.md` (what we're trying to do, kill criteria)
- Its `decisions.md` (has this come up before? did we already decide something adjacent?)
- `research/` and any synthesis file
- Recent meeting notes in `memory/meetings/` that mention the topic
- `MISSION.md` (does an option conflict with a project or a non-goal?)

## 3. Lay out the options

2 to 4 real options. One of them is usually "do nothing / ship as planned"; include it so the cost of inaction is visible. For each: what it costs (time, money, trust), what could go wrong, what it unblocks. Cite files.

## 4. Get the call

If I've already said what I want, write that. If I haven't, give a recommendation clearly labeled **Claude's read**, then ask me for the call. The decision is mine; the record should say whose call it was.

## 5. Write it

Prepend (newest on top) to `projects/<project>/decisions.md` using `templates/decision.md`:

```
## {YYYY-MM-DD} · {question as a short title}
**Call:** {the decision in one line}
**Made by:** {name}  **Status:** decided | trial | reversed

**Context:** ...
**Options considered:**
- A. ... (cost / risk)
- B. ...
**Why this one:** ...
**What would change our mind:** {specific signal}
**Revisit:** {date or trigger}
**Who needs to know:** {names} → [ ] told
```

## 6. Close the loop

For each person under "Who needs to know", add a commitment to `SPRINT.md` ("Tell {name} about {decision}") unless I say they already know.
