---
name: research
description: Synthesize raw research (interviews, call notes, support tickets, survey dumps, field notes) into findings that each carry quotes and a count. Writes a synthesis file into the project. Use when the user says synthesize, "what are we seeing", "what's the pattern", or points at an evidence folder.
argument-hint: "<path to evidence folder or project name>"
---

# /research $ARGUMENTS

## 1. Scope

- If `$ARGUMENTS` is a project name, use `projects/$ARGUMENTS/research/`.
- Read every file in the folder. Note how many sources there are (N) and what kind (interview, ticket, survey, observation).
- Read the project's `README.md` so you know which assumptions the evidence is testing.

## 2. Extract

For each source, pull out:
- **Said:** what the person told us (quote it)
- **Did:** what they actually do, if the notes show behavior (workarounds, tools, timing)
- **Felt:** strong emotion words, if present (quote them)

Behavior beats opinion. If someone says they'd pay but their notes show they use a free spreadsheet, both go in.

## 3. Find patterns

Group what you extracted into findings. Each finding gets:
- A plain-English headline (a claim, not a topic: "New users don't trust numbers they can't check", not "Trust")
- A count: **n of N** sources
- 1 to 3 direct quotes, each tagged with the source file
- A confidence label: **strong** (most sources, consistent), **emerging** (2 or more sources), **one voice** (1 source; worth noting, not worth building on)

## 4. Check the assumptions

Add a section called "What this does to our assumptions". For each assumption in `README.md`, say: supported / weakened / no evidence yet. This is where the synthesis earns its keep.

## 5. Write it

Save to `projects/<project>/synthesis.md` (if one exists, save as `synthesis-YYYY-MM-DD.md` and keep the old one). Structure:

```
# Synthesis · {project} · {date}
Sources: {N} ({breakdown})

## Headline
{2-3 sentences a busy exec could read alone}

## Findings
### 1. {claim}  · {n of N} · {strong|emerging|one voice}
> "{quote}" ({source file})

## Surprises
## What this does to our assumptions
## Open questions (what we still don't know)
```

## Rules

- No quote, no finding.
- Never paraphrase a quote and keep the quote marks.
- If N is under 5, say so in the headline; small samples are fine, pretending they aren't is not.
