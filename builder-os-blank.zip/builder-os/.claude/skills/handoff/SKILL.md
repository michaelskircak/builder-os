---
name: handoff
description: Move work between Builder OS and a build pipeline (Shipline, or any spec-to-code workflow). "out" packages a project's problem, evidence, decisions, and constraints into one handoff file a build pipeline can start from. "in" takes what came back from the build (decisions made during build, scope changes, ship dates, what shipped) and files it into decisions, the sprint, and memory. Use when the user says handoff, "send this to build", "ready for spec", "sync back from the build", or pastes build updates.
argument-hint: "out <project> | in <project> (then paste updates)"
---

# /handoff $ARGUMENTS

Builder OS is where you decide **what** and **why**. A build pipeline is where it becomes a spec, tickets, and code. This command is the doorway between them, in both directions.

## out: package a project for the build

1. Read `projects/<project>/README.md`, `decisions.md`, the newest `synthesis*.md`, and anything in `artifacts/`.
2. Read `MISSION.md` (non-goals) and `context/product.md`, `context/glossary.md`.
3. Write `projects/<project>/artifacts/handoff-YYYY-MM-DD.md`:

```
# Handoff · {project} · {date}

## The problem (one paragraph, no solution yet)
## Who has it (specific people or segments, from research)
## Evidence
- {finding} · {n of N} · "{quote}" ({source file})
## Decisions already made (don't reopen)
- {date} · {call} · {why, one line}
## Constraints
- Dates, budget, freezes, non-goals, things legal/payments must approve
## What success looks like (one measurable outcome)
## Open questions for the build
- {question} · {who can answer}
## Glossary (terms the build should use)
```

4. Rules: no solution design beyond what's already in `decisions.md`. Every evidence line has a source. If something the build will obviously need is missing (a success metric, a date), list it under Open questions instead of inventing it.
5. Add to `SPRINT.md`: "Handoff sent for {project}", and to `memory/done/`.

## in: file what came back from the build

The user pastes updates: a spec summary, decisions made during build, scope cuts, a new ship date, release notes.

1. **Decisions made during build** → prepend to `projects/<project>/decisions.md` using `templates/decision.md`, with **Made by** set to whoever made them and a line "From the build."
2. **Scope changes** that conflict with something in `decisions.md` or the README's "What done looks like" → don't overwrite. Flag the conflict and suggest `/decide`.
3. **Dates** → update the project row in `MISSION.md` only after asking. Add date-driven commitments to `SPRINT.md` (for example, "Tell Tamsin the confirm screen ships Oct 28").
4. **Shipped** → `memory/done/YYYY-MM.md`, and a line in today's `memory/daily/` note so `/weekly` picks it up.
5. **People** who need to hear about any of it → check `team/` files and add tell-them commitments.
6. End with a receipt of every file touched, like `/debrief`.
