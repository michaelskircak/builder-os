# Backlog

Everything you might do. Promote to `SPRINT.md` when it earns a slot. `/capture` adds here; `/cleanup` cleans it.

## {{Project or area}}
- {{idea / to-do}}

## Me
- {{career, learning, someday}}
