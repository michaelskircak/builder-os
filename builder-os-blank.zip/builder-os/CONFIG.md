# Config

How this OS is wired. Claude reads this when it needs to know what's connected.

## Connections
| Tool | What for | Status |
|---|---|---|
| {{calendar}} | Meetings for /brief and /prep | {{connected / could connect / files only}} |
| {{tracker: Linear, Jira, Asana, GitHub…}} | Tasks and tickets | {{status}} |
| {{chat: Slack, Teams…}} | Team chat | {{status}} |
| {{docs: Notion, Google Drive, Confluence…}} | Docs and wiki | {{status}} |
| {{other: CRM, analytics…}} | | {{status}} |

If a connection isn't available, commands say so once and use files.

## Conventions
- Dates: `YYYY-MM-DD` everywhere. Day logs: `memory/daily/YYYY-MM-DD.md`
- People files: `team/first-last.md`
- Meeting files: `memory/meetings/YYYY-MM-DD-short-slug.md`
- Status emoji: 🟢 🟡 🔴 ⚪. Stuck waiting-on: 🧊
- Newest on top in every log-style file
