# Mission · {{Your name}}

## Me
- **Role:** {{title}}, {{company}} (since {{when}})
- **Own:** {{products, areas, accounts, systems, or outcomes you're responsible for}}
- **Report to:** {{manager}}
- **Work closest with:** {{team or pod}}

**What I'm for, in one line:** {{the outcome your job exists to produce}}

## {{This quarter / half}}: what a win looks like
{{One or two sentences.}}

## Projects

| Project | Target | Status | Now |
|---|---|---|---|
| {{project name}} | {{number or observable outcome}} | ⚪ | {{one line}} |

Status key: 🟢 on track · 🟡 at risk · 🔴 off track · ⚪ not started

## Not doing this {{quarter}}
- {{non-goal}}

## Metrics I watch
- **{{metric}}:** {{current value}} (definition in `context/metrics.md`)

## Team at a glance

| Person | Role | Why they matter to me |
|---|---|---|
| {{name}} | {{role}} | {{one line}} |
