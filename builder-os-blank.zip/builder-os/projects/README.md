# Projects

One folder per piece of work big enough that you'd lose the thread if you stepped away for a week: a feature, a launch, a campaign, a migration, a hire, a big deal.

Create one with `/new-project <name>`. Each gets:

```
projects/<name>/
├── README.md      ← what, why, done-looks-like, assumptions. Claude starts here.
├── decisions.md   ← every call, newest first (/decide writes here)
├── research/      ← raw research, interviews, data
└── artifacts/     ← specs, drafts, decks, anything you make
```

Point Claude at a project folder and it has the full context: "Let's work in `projects/checkout-redesign/`."
