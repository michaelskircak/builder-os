# Glossary

Terms Claude needs so it uses your team's language correctly: acronyms, internal project names, industry words.

- **{{term}}:** {{meaning}}
