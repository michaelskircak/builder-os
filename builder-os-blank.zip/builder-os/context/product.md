# {{Product / service / what you work on}}

{{What it is, who uses it, how it makes money, the main parts. If you're not in product, describe the "thing" your work feeds: the platform, the campaign engine, the sales motion.}}

## Key numbers
- {{metric}}: {{value}} ({{date, source}})
