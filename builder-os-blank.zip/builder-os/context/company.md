# {{Company}}

**What we do:** {{one sentence}}

- **Size:** {{people}}
- **Stage / business model:** {{e.g. Series B SaaS, agency, public company division}}
- **Where:** {{HQ / remote}}

## How decisions get made
- {{who decides what; how dates get set; where priorities come from}}

## Calendar that matters
- {{planning cycles, freezes, big seasonal moments, recurring deadlines}}
