# Customers

{{Who you serve: external customers, internal teams, or both. Segments, what they care about, what they complain about.}}
