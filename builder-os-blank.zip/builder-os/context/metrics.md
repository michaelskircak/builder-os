# Metrics: definitions and where they live

If a number isn't here or in a project's `research/`, Claude shouldn't quote it.

| Metric | Definition | Where it lives | Latest |
|---|---|---|---|
| {{metric}} | {{exact definition}} | {{dashboard / tool / person}} | {{value (date)}} |
