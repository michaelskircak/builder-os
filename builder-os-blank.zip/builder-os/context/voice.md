# Voice

> `/onboard voice` replaces this with rules pulled from your own writing. Until then, these defaults apply.

## Rules
- **Open with the thing.** First sentence is the news or the ask.
- **Numbers over adjectives.**
- **Say the bad news plainly, then what you're doing about it.**
- **Mix sentence lengths.** Some short. Some that take a little longer to land.
- **Contractions.** don't, we're, it's.
- **Use names.** "Priya's team" beats "the relevant stakeholders."

## Words to cut
leverage, utilize, synergy, robust, seamless, delve, empower, unlock, game-changer, streamline, facilitate, "circle back", "just wanted to", "excited to share", "it's worth noting"

## Things I overuse
- {{filled by /onboard voice}}

## Samples of my writing
> {{paste 2 or 3 messages that sound like you}}
