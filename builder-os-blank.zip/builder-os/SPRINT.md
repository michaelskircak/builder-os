# Sprint · week of {{YYYY-MM-DD}}

**Focus:** {{the one sentence that makes this week a win}}

## Commitments
- [ ] {{what}} · for {{who}} · due {{date}}

## Waiting on
- **{{who}}:** {{what}} · asked {{date}}

## Parked (not this week, on purpose)
- {{thing}}
