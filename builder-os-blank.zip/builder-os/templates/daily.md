# {{Weekday, YYYY-MM-DD}}

## Brief
{{written by /brief}}

## Log
- {{time}}: {{what happened}}

## End of day
{{written by /eod}}
