# Interview · {{name}} · {{YYYY-MM-DD}}

**Who:** {{name}}, {{role}}, {{company/context}}
**Why them:** {{what makes their perspective useful}}
**Project:** {{project name}}  **Interviewer:** {{name}}  **Format:** {{call / in person / site visit}}

## Their world
{{Context: their setup, team size, tools, a normal day.}}

## The last time it happened
{{Walk through one specific recent instance of the problem. What they did, step by step.}}

## Workarounds
{{What they do today instead. Spreadsheets, sticky notes, other tools, other people.}}

## Quotes worth keeping
> "{{exact words}}"

## What surprised me

## Assumptions this touches
- {{assumption from README.md}}: supports / weakens / neutral
