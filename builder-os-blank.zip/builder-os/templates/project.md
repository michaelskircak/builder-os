# {{Project name}}

**Owner:** {{name}}  **Status:** ⚪ not started | 🟢 on track | 🟡 at risk | 🔴 off track
**Appetite:** {{how much time this is worth before we reassess}}
**Started:** {{YYYY-MM-DD}}  **Check-in:** {{YYYY-MM-DD}}

## The problem
{{Who has it, in what moment. A specific person beats a category.}}

## Why now
{{What changed.}}

## What done looks like
{{One number or observable outcome.}}

## Assumptions to test
1. {{assumption}} → test: {{how we'll know}}
2. {{assumption}} → test: {{how we'll know}}

## Kill criteria
{{What would make us stop early.}}

## Not doing
- {{scope we're explicitly leaving out}}

## People
| Who | Role on this project |
|---|---|
| {{name}} | {{role}} |

## Map of this folder
- `decisions.md`: every call we've made, newest first
- `research/`: raw research
- `synthesis.md`: what the evidence says (from `/research`)
- `artifacts/`: specs, drafts, decks
