## {{YYYY-MM-DD}} · {{short title of the question}}
**Call:** {{the decision in one line}}
**Made by:** {{name}}  **Status:** decided | trial | reversed

**Context:** {{what forced the question}}

**Options considered:**
- A. {{option}} ({{cost / risk}})
- B. {{option}} ({{cost / risk}})

**Why this one:** {{reasoning, citing evidence files}}
**What would change our mind:** {{a specific signal}}
**Revisit:** {{date or trigger}}
**Who needs to know:** {{names}} → [ ] told
