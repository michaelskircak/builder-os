# {{Full Name}}

**Role:** {{title, team or company}}
**Relationship:** {{manager / peer / report / customer / partner / exec}}
**aka:** {{nicknames, handles, email}}
**Meet:** {{cadence, e.g. weekly 1:1 Tue}}

## How to work with them
- **Best format:** {{e.g. bottom line first, bullet points, a quick call, a story}}
- **Channel:** {{where they actually reply}}
- **Hates:** {{surprises, long emails, vague asks…}}

## What they care about
- {{what they get measured on / lose sleep over}}

## Open loops
- I owe: {{…}}
- They owe: {{…}}

## Notes over time
- {{YYYY-MM-DD}}: {{something learned, in their words if possible}}
