Subject: {{Team/area}} weekly update · week of {{Mon DD}}

**Headline:** {{one sentence: the thing they need to know if they read nothing else}}

**Moved**
- {{progress with a number}}

**Stuck / at risk**
- {{issue}} → {{what I'm doing about it}} → {{what I need, from whom}}

**Next week**
- {{the 1-3 things that matter}}

**Projects**
| Project | Status | One line |
|---|---|---|
