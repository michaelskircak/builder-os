# {{Meeting name}} · {{YYYY-MM-DD}}

**Who:** {{attendees}}
**Project:** {{related project, if any}}

## Prep
{{written by /prep}}

## Notes
{{written by /debrief}}

## Decisions
- {{decision}} → logged in {{projects/x/decisions.md}}

## Commitments
- [ ] {{who}}: {{what}} by {{when}}
