# 1:1s · {{name}}

Running log, newest on top. One entry per meeting.

---

## {{YYYY-MM-DD}}
**Their topics:**
**My topics:**
**Notes:**
**Commitments:**
- [ ] {{who}}: {{what}}
