# Changelog

How this OS has changed. Newest on top.

- 2026-10-12: Added `/incident` + `runbooks/customer-incident/` with /new-skill (third customer incident this year; did the first two by hand)
- 2026-09-21: Added the `auto-split-v2` project
- 2026-09-04: Added `/weekly` runbook after four weeks of writing updates by hand
- 2026-08-31: Ran /onboard. Builder OS set up.
