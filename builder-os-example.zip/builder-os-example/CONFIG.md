# Config

How this OS is wired. Claude reads this when it needs to know what's connected.

## Connections
| Tool | What for | Status |
|---|---|---|
| Google Calendar | Meetings for /brief and /prep | connected (when available in session) |
| Jira | Eng tickets, project "SPLIT" | connected (when available in session) |
| Slack | Team chat | could connect · for now I paste threads into `inbox/` |
| Notion | Company wiki | files only · stable stuff copied into `context/` |
| Amplitude | Product analytics | files only · Rafa's reports land in project `research/` folders |

If a connection isn't available, commands say so once and use files.

## Conventions
- Dates: `YYYY-MM-DD` everywhere. Daily notes: `memory/daily/YYYY-MM-DD.md`
- People files: `team/first-last.md`
- Meeting files: `memory/meetings/YYYY-MM-DD-short-slug.md`
- Status emoji: 🟢 🟡 🔴 ⚪. Stuck waiting-on: 🧊
- Newest on top in every log-style file (decisions, 1:1s, notes over time)
