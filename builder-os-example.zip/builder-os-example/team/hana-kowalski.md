# Hana Kowalski

**Role:** Mobile + backend engineer. Building the Host dashboard and reminders.
**Relationship:** core team
**aka:** Hana, @hana.k
**Meet:** product sync Thu 9:30, ad hoc

## How to work with them
- **Best format:** a quick Loom or a sketch. She thinks visually and fast.
- **Channel:** Slack, replies within the hour.
- **Hates:** specs that change after she's started building without someone telling her why

## What they care about
- Shipping. Gets restless if a feature sits behind a decision for more than a few days.
- The Host dashboard; she's proud of it. (Gus hasn't opened his in two weeks. Be gentle about that.)

## Open loops
- They owe: rough estimate for pay-by-link (asked 10-20)

## Notes over time
- 2026-10-20: On pay-by-link: "So a guest taps a text and pays with Apple Pay, no account? Payments-wise that's Tomás's call, but the UI is maybe a week."
- 2026-09-22: Shipped automatic reminders 3 days early.
