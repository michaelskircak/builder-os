# Gus Ferreira

**Role:** Owner, Last Call Co. (Nashville). Runs ~12 bachelor and bachelorette weekends a month with 6 part-time trip hosts.
**Relationship:** pilot customer. 11 active trips. Renewal decision Oct 30.
**aka:** Gus, Augusto, gus@lastcallco.com
**Meet:** pilot check-ins every two weeks; extra call Thu 10-22 at 11:00

## How to work with them
- **Best format:** straight talk. Lead with what happened and what we're doing. He can smell spin.
- **Channel:** phone, then a short email he can forward to his business partner
- **Hates:** being "managed." Long emails. Percentages without dollars attached.

## What they care about
- His reputation with the families. Most of his bookings come from referrals: last year's bride is this year's maid of honor.
- His trip hosts. He brags about Luis, who's run 200+ weekends.
- Not looking dumb for trying new software. Other planners teased him for joining the pilot.

## Open loops
- I owe: written incident timeline + make-good offer, **promised by Thu 10-22**
- I owe: what we're changing in the model, in plain words
- They owe: nothing open

## Notes over time
- 2026-10-11: On the incident call: "The groom's mom called ME. Not you. Me."
- 2026-10-11: "I told my guys to trust your app over a napkin. That's on me once. It won't be twice."
- 2026-10-11: Emailed Bea directly, not me. They worked the same bar on Broadway in 2014.
- 2026-09-29: In the pilot interview: "I don't need another dashboard. I need Kyle to pay me."
- 2026-09-29: "If this saves me one Sunday of chasing Venmo, it's paid for."
