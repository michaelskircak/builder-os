# Imani Brooks

**Role:** Owner, Big Day Collective (Jersey City). Plans wedding weekends: welcome dinners, rehearsal dinners, group hotel blocks.
**Relationship:** pilot customer. Said yes to paying on 10-20.
**aka:** Imani, @bigdaycollective on Instagram
**Meet:** pilot check-ins every two weeks

## How to work with them
- **Best format:** text or a quick call. Very responsive. Likes being asked her opinion.
- **Channel:** text message
- **Hates:** anything that makes her look unprofessional in front of a couple's family

## What they care about
- Cash flow. Every subscription gets scrutinized. "$49 a month is a lot for a group chat."
- Her clients' guests never feeling nickel-and-dimed

## Open loops
- I owe: confirm 2 months free if she pays annually (need Coco's ok)
- I owe: ask why she hasn't turned on automatic reminders

## Notes over time
- 2026-10-20: In for paid, wants annual with 2 months free.
- 2026-10-20: "My couples' aunts are not downloading an app. I text them a Zelle number and pray."
- 2026-10-01: Tracks who paid in a Google Sheet she color-codes every Sunday night.
