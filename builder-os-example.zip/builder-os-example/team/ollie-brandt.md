# Ollie Brandt

**Role:** Product designer, Halvsies Host
**Relationship:** core team
**aka:** Ollie, @ollie
**Meet:** weekly 1:1 Mon 3:00, dashboard review Fri 10-23 at 2:00

## How to work with them
- **Best format:** raw quotes and screenshots from the field. He wants the source, not my summary of it.
- **Channel:** Figma comments for design feedback, Slack for everything else
- **Hates:** being handed a solution instead of a problem. Being left off customer calls.

## What they care about
- Seeing real usage. Has asked twice to shadow a trip host for a night.
- Not designing a dashboard nobody looks at

## Open loops
- I owe: pilot interview synthesis before Fri review
- I owe: try to get him on a Big Day wedding weekend (Imani is 10 minutes away)

## Notes over time
- 2026-10-19: "I keep designing for the planner. Who's actually holding the phone at the bar at midnight?"
- 2026-10-05: Asked for every screenshot pilots sent us. Made a wall of planners' Venmo-tracking spreadsheets.
