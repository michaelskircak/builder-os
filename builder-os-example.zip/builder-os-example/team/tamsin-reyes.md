# Tamsin Reyes

**Role:** Support lead (team of 8, plus 2 temps starting Nov 2)
**Relationship:** partner
**aka:** Tam, @tamsin
**Meet:** biweekly sync, next Tue 10-27

## How to work with them
- **Best format:** "here's what people will notice and when." She needs to brief her team before a change, not after.
- **Channel:** Slack #support-product
- **Hates:** finding out about a launch from a ticket

## What they care about
- NYE first-reply time (her team's big goal)
- Macros: she needs exact wording for anything user-facing a week ahead

## Open loops
- They owe: tickets since Oct 1 mentioning "wrong amount", "overcharged", "didn't order that" (asked 10-20)
- I owe: Auto-Split launch plan + user-facing wording at least a week before launch

## Notes over time
- 2026-10-20: "If Auto-Split ships Nov 5 I need macros by Oct 29. Earlier is better."
- 2026-10-11: Her team refunded both groomsmen within 10 hours of the first ticket, on a Sunday.
