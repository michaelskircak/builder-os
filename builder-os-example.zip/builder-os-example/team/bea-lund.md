# Bea Lund

**Role:** CEO and cofounder, Halvsies. Spent 8 years bartending and running restaurant floors in Nashville and New York.
**Relationship:** exec, two levels up. Host was her idea.
**aka:** Bea, @bea
**Meet:** no recurring. Pops into Slack. Monthly product review.

## How to work with them
- **Best format:** a story about a real person, then the number. She glazes over at dashboards and lights up at "Pete turned reminders on for every trip on day one."
- **Channel:** Slack. Replies fast, at all hours.
- **Hates:** jargon ("don't say 'users', say who they are"), slides with more than one chart, "we can't" without a "but here's what we can do"

## What they care about
- Trust with money. She'll say "a wrong charge is a wrong charge" when people talk about averages.
- Host as proof Halvsies isn't "just a Venmo calculator"
- Personal relationships with pilot planners. She knows Gus from bartending in Nashville.

## Open loops
- I owe: pricing one-pager by Mon 10-26
- I owe: an update on Gus before she decides whether to call him herself (see `inbox/2026-10-22-bea-slack.md`)

## Notes over time
- 2026-10-22: Slacked at 7:12am asking if she should call Gus herself.
- 2026-10-11: Gus emailed Bea directly about the tab, not me. They worked the same bar on Broadway in 2014. Expect this pattern.
- 2026-09-30: In product review: "Planners don't want a dashboard. They want their money back without being the bad guy." Didn't land at the time; worth revisiting.
- 2026-09-02: Wants Host priced "like something a small business buys without a meeting."
