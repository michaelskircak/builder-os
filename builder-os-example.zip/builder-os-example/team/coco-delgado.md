# Coco Delgado

**Role:** Head of Product, Halvsies
**Relationship:** my manager
**aka:** Coco, @coco, coco@halvsies.com
**Meet:** weekly 1:1 Tue 10:15 (moved to Thu this week)

## How to work with them
- **Best format:** bottom line first, then the two or three things behind it. She reads the first line and decides whether to keep going.
- **Channel:** Slack DM for anything time-sensitive. Docs for anything she needs to forward.
- **Hates:** hearing about a problem from someone else first, especially Bea. Options without a recommendation.

## What they care about
- Not being surprised in the Monday leadership meeting
- Host as the Series B story (she says "B2B proof" a lot)
- Dates that hold. She'd rather move a date early than miss it late.
- The team not burning out before New Year's

## Open loops
- I owe: Auto-Split launch recommendation by Fri 10-23 (she asked 10-20: "Bring me a call, not a menu.")
- I owe: heads-up on Last Call renewal odds before Monday leadership
- They owe: answer on whether in-app NYE tips count as "content" (not-doing list)

## Notes over time
- 2026-10-20: "Bring me a call, not a menu." Re: Auto-Split launch.
- 2026-10-11: Heard about the Nashville tab from Bea before she heard it from me (I was on the phone with Gus). Said: "I don't love hearing about customer fires from Bea." Fair. Now: any customer fire → Coco gets a 2-line Slack within 30 min, even if I don't know much yet.
- 2026-09-08: Likes that I send pilot quotes in Slack. "Keep doing that, Bea eats it up."
- 2026-08-25: Prefers decisions written down. Asked me to keep a decision log per project (that's where `decisions.md` came from).
