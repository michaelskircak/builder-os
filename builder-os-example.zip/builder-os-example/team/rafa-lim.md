# Rafa Lim

**Role:** Data analyst, shared between Product and Growth
**Relationship:** partner
**aka:** Rafa, @rafa
**Meet:** data review Thu 1:30 this week, otherwise ad hoc

## How to work with them
- **Best format:** a specific question plus the decision it feeds. "How many X" without the why gets you a number; with the why it gets you the right number.
- **Channel:** Jira ticket in the DATA project, then a Slack ping
- **Hates:** same-day requests. Needs ~2 working days. Numbers quoted without the caveat he attached.

## What they care about
- Metric definitions staying consistent (he wrote `context/metrics.md` with me)
- Not being the bottleneck. Tells you early if something will be late.

## Open loops
- They owe: every Host receipt read since Sep 8, tagged by type, with confidence scores (asked 10-19, due ~10-21, data review Thu 1:30)

## Notes over time
- 2026-10-19: Warned the handwritten sample is thin: "a couple thousand reads total, and a lot of them are Last Call."
- 2026-10-12: Read-quality report by receipt type. The 58% handwritten number came from this.
