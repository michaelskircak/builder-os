# Dev Raman

**Role:** ML engineer. Owns the receipt-reading model and Auto-Split end to end.
**Relationship:** core team
**aka:** Dev, @devr
**Meet:** weekly 1:1 Wed 2:00, product sync Thu 9:30

## How to work with them
- **Best format:** written problem statement with the data attached. He'll read it carefully and come back with something better than what I asked for.
- **Channel:** Jira comments or a doc. Slack only for quick yes/no.
- **Hates:** meetings before noon (focus block), "how long will it take" before he's seen the data, people calling the model "the AI"

## What they care about
- Doing it right. Will push back on shipping something he thinks is wrong, quietly but firmly.
- Labeled data. Half his frustration is that we have very few labeled handwritten tabs.
- Credit going to the team, not to him

## Open loops
- They owe: handwritten + low-light error analysis (blocked on Rafa's export)
- I owe: introduce him to Gus if Gus asks (he might want to talk to "the model guy")

## Notes over time
- 2026-10-14: In triage: "The model isn't broken. It's read maybe 20,000 handwritten tabs in its life and two million printed ones. That's a data problem pretending to be a model problem."
- 2026-10-14: Suggested a guardrail: when the read is low-confidence or the receipt looks handwritten, don't auto-send; show the photo with the total circled and make the payer confirm. ~2 days.
- 2026-09-14: Argued against auto-assigning tip and tax by default. Was right.
