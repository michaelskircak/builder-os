# Pete Novak

**Role:** Head of ops, Wanderpack (Austin). Runs 3-day team offsites for startups, 20 to 60 people each.
**Relationship:** pilot customer. Said yes on 10-21, wants per-business pricing.
**aka:** Pete, @petenovak
**Meet:** pilot check-ins every two weeks

## How to work with them
- **Best format:** blunt and short. Voice memos. He'll send a 4-minute memo and expect a 2-line reply.
- **Channel:** voice memo or text
- **Hates:** being asked the same question twice. Marketing language.

## What they care about
- His clients' finance teams. Every charge needs a receipt photo they can expense.
- Speed. Offsites close their books within a week.

## Open loops
- I owe: answer on a finance export with receipt photos (parked until pricing is set)

## Notes over time
- 2026-10-21: In for paid. "Per business, not per trip, or I'm counting trips every month like an idiot."
- 2026-10-21: A taco truck receipt got read as $84 instead of $64 on Monday's offsite. His trip host Marco caught it on the review screen. Wanderpack still uses v1 review on every split.
- 2026-10-06: "My people don't Venmo each other. They expense it. They need a PDF, not an app."
- 2026-10-06: "I still check every split before it sends. Your app's the first draft."
