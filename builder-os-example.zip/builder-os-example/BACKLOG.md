# Backlog

Everything I might do. Promote to `SPRINT.md` when it earns a slot.

## Halvsies Host
- Pay-by-link for guests who won't download the app (Gus, Imani, Pete all asked in some form)
- Finance export with receipt photos attached, from Pete 10-06
- Pricing test: per business vs per trip. Ask Rafa about a fake-door on the pricing page
- Case study with Big Day once they're paying (Imani said yes in principle)

## Auto-Split
- Sanity cap: if one person's share is 3x the group's usual, ask before sending. Dev says it's cheap
- Ask Dev whether tip-line reads have the same problem as totals
- 60-day beta survey

## NYE
- New Year's Eve "big tab" tips in the app? (Not-doing list says no content. Ask Coco if this counts.)

## Me
- Write up how I run pilots so the next PM doesn't start from zero
- Sit with Tamsin's team for an hour and just read tickets
