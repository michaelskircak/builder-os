# Shape

```
Subject: Host + Auto-Split · week of {Mon DD}

{Headline: one or two sentences. The thing Coco needs if she reads nothing else.}

**Moved**
- {progress, named people, a number}

**Stuck / at risk**
- {issue} → {what I'm doing} → {what I need, from whom, by when}

**Planners**
- {one real moment from a pilot, for Bea}

**Next week**
- {2 or 3 things}

| Project | Status | One line |
|---|---|---|
| Halvsies Host → paid | 🟡 | |
| Auto-Split v2 | 🔴 | |
| NYE readiness | 🟢 | |

J
```
