# Steps

## 1 · gather
Create `drafts/YYYY-MM-DD/` (the Friday's date). Pull from every source in `sources.md` that's available. Write everything to `drafts/YYYY-MM-DD/raw.md` as plain bullets grouped by project, with the source next to each.

**Checkpoint:** Show Jules the raw list and ask:
- "Which 2 or 3 of these does Coco need to know?"
- "Anything that happened that isn't in the files?" (hallway conversations, Slack DMs)
- "Did any project's status change?"

Save her answers at the bottom of `raw.md` under `## Jules's picks`.

## 2 · draft
Read `raw.md` (especially Jules's picks), `readers.md`, `shape.md`, and the last two files in `sent/`. Write `drafts/YYYY-MM-DD/draft.md`.

**Checkpoint:** Show the draft. Ask: "Anything wrong, missing, or too soft?"

## 3 · polish
Apply `context/voice.md` (same rules as `/polish`). Then run the reader check: for each reader in `readers.md`, does the draft answer the question they always ask? Add a line at the top of the file: `<!-- polished -->`.

**Checkpoint:** Show the final and the 3 to 5 biggest edits.

## 4 · send
Jules sends it herself (Slack or email). After she says "sent":
- Copy final to `sent/YYYY-MM-DD.md`
- Add "Weekly weekly update sent" to `memory/done/YYYY-MM.md`
- Check off the weekly update commitment in `SPRINT.md`
