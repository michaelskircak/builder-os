# Runbook: weekly update

You're helping Jules write her Friday update. It goes to Coco by 4pm, and Coco forwards pieces of it into Monday's leadership meeting. Bea reads it too. The team gets a copy.

**These rules apply while running this runbook and override general habits.**

## The four steps
1. **gather**: pull raw material, then stop and ask Jules what matters
2. **draft**: write it in the shape in `shape.md`, for the readers in `readers.md`
3. **polish**: run `/polish` rules from `context/voice.md`, then check against `readers.md`
4. **send**: copy to `sent/YYYY-MM-DD.md`, log it in `memory/done/`, clear the draft folder marker

Details for each are in `steps.md`. Run one step, then stop.

## Rules
- **Every number needs a source** in `sources.md` or a file in a project's `research/`. If it isn't there, write `[number?]` and flag it at the checkpoint.
- **Bad news goes in the headline when it's the biggest thing that happened.** Don't bury it.
- **Read the two most recent files in `sent/` before drafting.** Match their length and tone; don't repeat last week's lines.
- **Under 250 words.** Coco reads on her phone.
- **Projects table always at the bottom**, same emoji as `MISSION.md`. If a status changed, say why in one line.
