# Readers

| Reader | Reads it for | Question they always ask | Format notes |
|---|---|---|---|
| **Coco** (primary) | What to bring to Monday leadership | "Is anything going to surprise me?" | Bottom line first. If there's a decision she needs to make, say so in line 1. |
| **Bea** | How the planners are doing | "How's Gus / Imani / Pete?" | One sentence about a real person beats a metric. |
| **The team** (Dev, Hana, Ollie, Rafa) | Whether their work landed, what's next | "What's blocked on someone outside the team?" | Name them when their work moved something. |
| **Tamsin** | What users will notice | "Anything I need to brief my team on?" | Flag anything user-facing with dates. |
