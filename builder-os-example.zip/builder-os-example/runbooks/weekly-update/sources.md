# Sources

Where to look during **gather**, in order. Skip any that aren't available and say which.

| Source | What to pull |
|---|---|
| `SPRINT.md` | Checked-off commitments this week, waiting-on items |
| `memory/done/YYYY-MM.md` | Everything done since last Friday |
| `memory/daily/` (Mon to Fri) | End-of-day sections: "Shipped / moved", "Slipped", "Noticed" |
| `memory/meetings/` (this week) | Decisions and customer quotes |
| `projects/*/decisions.md` | Any decision dated this week |
| `MISSION.md` | Current project statuses (compare to last weekly update) |
| Jira (if connected) | Tickets closed this week in project SPLIT |
| `context/metrics.md` + project `research/` | Numbers. Only numbers with a date and a source. |
