# Runbooks

A runbook is repeat work with more than one step, its own reference files, and rules that only apply while you're running it. Each has a `CLAUDE.md` that Claude reads first.

Projects end; runbooks repeat. If you've done something by hand three times, run `/new-skill` and turn it into one.

| Runbook | Command | Runs | Added |
|---|---|---|---|
| [weekly-update](weekly-update/) | `/weekly` | Every Friday | 2026-09-04 |
| [customer-incident](customer-incident/) | `/incident` | When a customer gets burned | 2026-10-12 |
