# Steps

## 1 · open (first 30 minutes)
- Create `open/<customer-slug>-<incident-date>/`
- `what-we-know.md`: who, what they lost, when, what we think happened (labeled as a guess)
- Draft the 2-line internal Slack: "{customer} {lost what} {when}. Looking into it now, update by {time}." Jules sends it.
- Add to `SPRINT.md`: follow-up commitment with a date

**Checkpoint:** Jules confirms the internal note went out.

## 2 · timeline
- Pull data: telemetry, tickets, logs, the customer's own account (from meeting notes)
- Write `timeline.md`: time, what the data shows, what the customer did, what our product did
- Mark the moment it went wrong and why, in one plain sentence

**Checkpoint:** Jules reviews. Engineering owner confirms the facts.

## 3 · make-good
- Read `make-good-menu.md` and the customer's team file
- Propose one option sized to the loss, and one alternative
- Write `make-good.md`

**Checkpoint:** Jules picks. If over the "needs Coco" line, flag it.

## 4 · follow-up
- Talk first if the team file says they prefer calls. Then write `follow-up-note.md`: owns it, what happened (from the timeline), what we're changing, the make-good, when they'll hear from us next. Under 200 words.
- Run `/polish` on it.
- Schedule the next check-in in `SPRINT.md`.

## 5 · close
- When the customer says it's resolved (or 30 days pass quietly), move the folder to `past/`
- Add a "Lessons" section
- If the incident changed a product decision, make sure it's in the project's `decisions.md`
