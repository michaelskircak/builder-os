# Runbook: customer incident

Built 2026-10-12 with `/new-skill` after the third time this year a customer got burned by something we shipped. Run with `/incident`.

You're helping Jules respond to a customer who lost something real (money, time, face) because of us. The goal is to keep their trust, not to win an argument about whose fault it was.

**These rules apply while running this runbook and override general habits.**

## Steps (see `steps.md`)
1. **open**: create the incident folder, write what we know in 10 minutes, notify internally
2. **timeline**: build the factual timeline from data, not memory
3. **make-good**: pick from `make-good-menu.md`, sized to what they lost
4. **follow-up**: the written note, then check-ins until it's closed
5. **close**: move to `past/`, log lessons, update the project's `decisions.md` if something changed

## Rules
- **Internal heads-up within 30 minutes.** Two lines to Coco in Slack, even if we know almost nothing. (Lesson from 2026-10-11.)
- **Facts in the timeline come from data only.** Read logs, payment records, tickets. Not "I think it was around midnight."
- **Own it in the first sentence of anything we send.** No "we're sorry you feel," no "some users may have experienced."
- **Never promise a fix date we don't control.** Say what we're doing and when we'll update them.
- **Their team file is the format guide.** Gus gets a phone call before an email.
- Write everything to `open/<customer>-<YYYY-MM-DD>/`.
