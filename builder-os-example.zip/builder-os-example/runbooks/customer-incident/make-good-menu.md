# Make-good menu

Size it to what they lost. Over-correcting feels like a bribe; under-correcting feels like we don't get it.

| Loss | Options | Needs Coco? |
|---|---|---|
| Inconvenience, no money lost | Personal note, early access to the fix | No |
| Consumer overcharged, refunded | Refund + 3 months Halvsies Plus free | No |
| Business customer, under $500 at stake | 2 to 3 months Host free | No |
| Over $500, or public / reputational damage | 3 months free + something personal (a call from Bea, the engineer walks them through the fix) | Yes |
| Anything involving Bea's personal relationships | Loop Bea before offering | Yes |

**What customers have told us they actually value:**
- Being told the real cause (every incident so far)
- Talking to the person who fixed it (Gus asked; the August double-charge customer asked)
- Being first to get the fix
