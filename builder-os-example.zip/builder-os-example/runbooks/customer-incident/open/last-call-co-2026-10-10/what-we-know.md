# What we know · Last Call Co. · 2026-10-10

Written 2026-10-11, 9:50am. Updated 10-12.

- **Who:** Gus Ferreira, Last Call Co. (Host pilot). Trip: "Kyle's Last Rodeo," Nashville bachelor party, 14 guests.
- **What happened:** Auto-Split read a handwritten $1,140 tab as $7,140 and sent 13 guests $612 requests. Two paid ($1,224). Both refunded Sun 10:05am.
- **Public:** Best man's TikTok, 1.4M views by 10-21.
- **Why (confirmed by Dev 10-12):** handwritten "1" with a serif read as "7". Receipt misclassified as printed. Model has seen very few handwritten tabs.
- **Internal note:** sent to Coco 10-11, 11:50am. Late. Bea had already told her.
