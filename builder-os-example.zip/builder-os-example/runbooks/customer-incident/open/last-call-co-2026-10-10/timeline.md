# Timeline · Last Call Co. · Sat Oct 10 to Sun Oct 11

Facts from read logs and payment records (`projects/auto-split-v2/research/nashville-tab-read-log.md`) and Gus's account (`memory/meetings/2026-10-11-last-call-incident-call.md`). Confirmed by Dev 10-21.

| Time (CT) | What happened |
|---|---|
| Sat 23:41 | Luis photographs the bar tab. It's handwritten, under dim string lights. |
| 23:41 | Halvsies reads the total as **$7,140.00**. The real total is **$1,140.00**. |
| 23:41 | Auto-Split adds a 20% tip and splits 14 ways: **$612 each** (should have been $97.71). |
| 23:42 | Luis taps send. 13 guests get a request. |
| 23:43 to 23:46 | Two guests pay $612 each with saved cards. |
| 23:58 | The best man flags it in the group chat. |
| Sun 00:20 | Luis cancels the remaining 11 requests. |
| 08:10 | The best man posts a TikTok about it. |
| 09:30 | The groom's mother calls Gus. |
| 10:05 | Our support team refunds both guests in full. |

**Where it went wrong, in one sentence:** our model has seen very few handwritten receipts, read a handwritten "1" as a "7", and Auto-Split sent the requests without showing anyone the number first.

**What we're changing:** when a receipt looks handwritten, faded, or dark, or the model isn't sure, or anyone's share looks unusually high, Halvsies will show you the receipt with the total circled and ask you to confirm before anything sends. *(Pending Jules's launch call, due 10-23.)*
