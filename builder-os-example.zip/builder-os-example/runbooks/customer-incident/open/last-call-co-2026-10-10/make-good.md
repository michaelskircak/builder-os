# Make-good · Last Call Co.

At stake: $1,224 overcharged (refunded), a public TikTok, and Gus's standing with a referral-heavy client family. Public/reputational → needs Coco. Bea's personal relationship → loop Bea.

## Proposed
**3 months of Host free after renewal ($147) + early access to the fix, and Dev walks Gus (and Luis, if he wants) through what changed on a call.**
Why: Gus said he cares more about looking bad than the money. Talking to the person who fixed it is the thing customers value most (see `make-good-menu.md`).

## Alternative
6 months free + a $500 credit he can pass to the groom's family as an apology.
Why not first: risks feeling like we're paying him to stay. Gus "can smell spin."

## Status
- [ ] Coco ok (Slacked 10-21, no reply yet)
- [ ] Bea looped (Bea Slacked 10-22 asking about Gus; reply after the call)
- [ ] Offered to Gus
