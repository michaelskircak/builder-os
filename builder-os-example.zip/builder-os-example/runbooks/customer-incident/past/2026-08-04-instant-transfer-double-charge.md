# Incident · instant transfers charged twice · 2026-08-04

**Who:** ~900 users (first report: a user in Portland who'd paid her roommate's rent share)
**Lost:** duplicate debits ($12 to $1,400), overdraft fees for at least 30 people

## Timeline
- 08-01: Payments retry logic change ships. A timeout on the bank's side triggers a second debit instead of a status check.
- 08-01 to 08-03: 900 duplicate debits. Tamsin spots the ticket spike 08-03 evening.
- 08-04: Tomás confirms, rolls back, auto-reverses all duplicates within 6 hours.

## Make-good
Reversed every duplicate, refunded overdraft fees on proof (we paid 34), 3 months Plus free.

## Lessons
- 2.5 days to spot the pattern. Tamsin now flags any ticket spike over 3x baseline in #support-product.
- Users didn't want an apology email. They wanted their money back and to know it wasn't their fault.
