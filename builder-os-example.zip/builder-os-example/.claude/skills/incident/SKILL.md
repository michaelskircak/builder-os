---
name: incident
description: Run the customer-incident runbook when a customer loses money, time, or face because of something we shipped. Opens an incident folder, builds a data-backed timeline, sizes a make-good, and drafts the follow-up. Use when the user says incident, "a customer got burned", "we broke something for", or names a customer with a problem.
argument-hint: "[open <customer> | timeline | make-good | follow-up | close]"
---

# /incident $ARGUMENTS

Front door for `runbooks/customer-incident/`.

1. Read `runbooks/customer-incident/CLAUDE.md` and follow it for the rest of this task.
2. Work out the step:
   - `open <customer>` → step 1 for a new incident
   - A step name → that step for the most recent folder in `open/` (ask if there's more than one)
   - Nothing → look at the newest folder in `open/` and resume at the first step whose file is missing
3. Run one step. Stop at its checkpoint.

_Built by Jules with /new-skill on 2026-10-12._
