# Customers

## Consumers (~99% of users)
- 22 to 40, mostly urban, use Halvsies for roommates, dinners, and trips.
- Their pain: being the friend who fronted the bill and has to chase everyone.
- Receipts: overwhelmingly printed, from chain restaurants and stores. Snap Split is very good at these.
- Biggest support topics: bank linking, "I was charged twice" (usually a pending hold), and "the split is wrong."

## Group-trip planners (Host pilots)
- Small businesses that run group trips and events: 1 to 15 staff, often a founder plus part-time trip hosts.
- They front money (deposits, dinners, boats, bar tabs) and spend days afterward chasing guests to pay them back.
- On-site trip hosts do the snapping, often at night, in bars, from handwritten tabs. Not the owner.
- Guests are one-time users. Many will not download an app for one weekend.
- They care about getting paid and not looking bad in front of their clients. One wrong charge to a bride's family can cost them a referral network.

## Pilot planners
| Business | City | What they run | Contact | File |
|---|---|---|---|---|
| Last Call Co. | Nashville | Bachelor/bachelorette weekends, ~12 trips/month | Gus Ferreira, owner | `team/gus-ferreira.md` |
| Big Day Collective | Jersey City | Wedding weekends | Imani Brooks, owner | `team/imani-brooks.md` |
| Wanderpack | Austin | Company team offsites | Pete Novak, head of ops | `team/pete-novak.md` |
