# Halvsies

**What we do:** Take the awkward part out of splitting money with people. Snap the receipt, we do the math, everyone gets a request.

- **Founded:** 2022 by Bea Lund (CEO; 8 years bartending and running floors at restaurants in Nashville and New York) and Tomás Eriksen (CTO; previously a payments engineer at a large fintech)
- **HQ:** Brooklyn (DUMBO). Hybrid, in office Tue to Thu.
- **People:** 41 (16 eng, 5 product + design, 8 support, 4 data + ML, 8 marketing + ops + admin)
- **Funding:** Series A, $14M (2025). Series B conversations planned for Q2 2027; Host traction is the story.
- **Revenue:** Halvsies Plus ($3.99/mo, 6% of monthly actives) and instant-transfer fees. Host would be our first B2B revenue.

## How decisions get made
- Bea decides on anything that touches brand or a customer relationship she's personally involved in. She's personally involved in more of these than you'd expect.
- Coco owns product priorities. Tomás owns eng staffing, payments, and anything touching money movement.
- Launch dates get set in the Monday leadership meeting. Moving one needs a written reason.

## Calendar that matters
- **Monday 9:00** leadership meeting (Coco brings product items, so she needs them by Friday)
- **Friday by 4pm** weekly updates due to Coco
- **Friendsgiving week (Nov 23 to 27)** and **New Year's Eve** are our two biggest nights of the year. Nothing ships Thanksgiving week.
- **Feature cutoff:** Nov 13. **Code freeze:** Dec 14 to Jan 4.
