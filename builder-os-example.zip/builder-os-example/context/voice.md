# Voice: how Jules writes

Set up with /onboard on 2026-08-31 from three Slack messages and two past updates. Edited by hand since.

## The short version
Plain, warm, specific. Sounds like someone who has split a lot of bar tabs, because I have.

## Rules
- **Open with the thing.** First sentence is the news or the ask. No "Hope everyone had a great week."
- **Numbers over adjectives.** "We read 58% of handwritten tabs right," not "accuracy is lower on some receipts."
- **Say the bad news plainly, then what I'm doing about it.** Never bury it in the third bullet.
- **Use people, not "users."** Groomsmen, planners, the trip host.
- **Short sentences are fine. All short sentences are not.** Mix lengths.
- **Contractions always.** I'm, we're, didn't.
- **Sign off with just "J".**

## Words I don't use
leverage, utilize, synergy, robust, seamless, delve, empower, unlock, game-changer, "circle back", "per my last message", "just wanted to", "excited to share"

## Things I overuse (catch me)
- "honestly"
- starting bullets with "So,"
- "a bit"

## Samples

> Auto-Split read a handwritten $1,140 tab as $7,140 last night and sent 13 groomsmen a $612 request each. Two paid. Tamsin's team is refunding now. It's a Last Call Co. trip. I'm on the phone with Gus at 2. More by end of day. J

> Quick one: Big Day is in for paid. Imani wants to pay annually if we'll do 2 months free. I said probably and that I'd confirm by Friday. Coco, ok with me saying yes?

> Shipped automatic reminders to all three pilots. Pete's already turned them on for every trip. Imani hasn't touched them. Going to ask her why tomorrow.
