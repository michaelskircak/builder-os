# Metrics: definitions and where they live

Rafa owns all of these. If a number isn't here or in a Rafa report, don't quote it.

| Metric | Definition | Where | Latest |
|---|---|---|---|
| Monthly active splitters | Users who created or paid a split in the last 30 days | Amplitude "Core" | 2.3M (Oct 19) |
| Exact-total rate | % of reads where the model's total matches the confirmed total | Rafa's weekly read-quality report | 95% overall · 97% clean printed · 58% handwritten · 71% low light (Oct 11) |
| Bad-send rate | % of Auto-Split sends later edited or refunded because of a wrong read | same | 0.4% consumers · 3.1% Host pilots |
| Host trips active | Host trips with an expense in the last 7 days | Amplitude "Host" | 27 |
| Crash-free sessions | % sessions with no crash, 7-day | Crashlytics | 99.7% |
| First-reply time | Median time to first human reply on a ticket | Zendesk | 2h 40m (Oct) |
