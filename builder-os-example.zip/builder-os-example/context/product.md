# Halvsies: the product

## Core app (iOS, Android, web)
- **Groups:** a trip, a house, a dinner. Everyone in it can add expenses.
- **Requests + settle up:** pay by bank, debit card, or Apple/Google Pay. Instant transfer costs 1.5%.
- **Snap Split (v1, since 2025):** photograph a receipt. Our model reads every line item, tax, tip, and the total. You tap who had what, **review the amounts**, then send requests.
- **Auto-Split (v2, beta since Sep 28):** same read, but it assigns items using the group's history and sends requests in **one tap, with no review screen**. Beta: 3 Host pilots + 20,000 consumer users. See `projects/auto-split-v2/`.
- **Halvsies Plus ($3.99/mo):** unlimited groups, receipt history, export, custom split rules.

## Halvsies Host (pilot, Sep 8 to Oct 30)
- For people who organize group trips and events for a living: bachelor/bachelorette weekends, weddings, team offsites.
- One dashboard for every trip: deposits, shared costs, who's paid, automatic reminders.
- Guests currently need the Halvsies app to pay. (This comes up a lot.)
- Pilot pricing: free. Proposed: $49/month per business.
- 3 pilots, 27 active trips/events. See `projects/halvsies-host/`.

## Numbers (as of Oct 19, from Rafa)
- Monthly active splitters: 2.3M
- Receipts read per week: ~210,000
- Halvsies Plus subscribers: 138,000
- App rating: 4.7 iOS, 4.5 Android (Android dipped from 4.6 after the TikTok)
