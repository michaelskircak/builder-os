# Glossary

Our words, so Claude uses them the way the team does.

- **Split:** dividing one expense among people. **Request:** the payment ask each person gets.
- **Settle up:** paying what you owe in a group.
- **Read:** the model's interpretation of a receipt: line items, tax, tip, total.
- **Exact-total read:** the total the model read matches the real total to the cent.
- **Confidence score:** 0 to 1, the model's own estimate of how sure it is about a read.
- **Snap Split:** v1. Read → you assign → **you review** → send.
- **Auto-Split:** v2. Read → auto-assign → **send in one tap**. The missing review step is the whole feature, and also the whole risk.
- **Clean receipts:** printed, unwrinkled, decent light. Where the model is strong.
- **Hard receipts:** handwritten tabs, faded thermal paper, low light. Where it isn't.
- **Planner / organizer:** the Host customer. **Trip host:** the planner's staffer on site. **Guest:** a person on the trip who owes money.
- **Pay-by-link:** (proposed) a guest pays from a text or email link without installing the app.
