# 1:1s · Coco Delgado

Newest on top.

---

## 2026-10-20
**Her topics:** Auto-Split launch. Last Call renewal odds. Monday leadership is going to ask about both.
**My topics:** Imani's annual discount (ran out of time, didn't ask).
**Notes:**
- "Bring me a call, not a menu." She wants one recommendation by Friday, with the reason in writing she can take to leadership.
- Doesn't want to move Nov 5 unless we have to. "Moving launch dates is how you lose the room."
- Asked about Last Call: told her 50/50. She wants an update before Monday.
**Commitments:**
- [ ] Jules: Auto-Split launch call by Fri 10-23
- [ ] Jules: Last Call renewal odds before Mon leadership

## 2026-10-13
**Her topics:** Q4 projects check. Holiday freeze. The TikTok.
**My topics:** Host pricing timeline.
**Notes:**
- Marketing wants to reply to the TikTok. Coco said not until we have the fix. Agreed.
- Wants pricing locked before Nov 1.
- Reminded me Bea will want to talk to Gus personally about anything big.
**Commitments:**
- [x] Jules: pricing one-pager draft to Bea by 10-26 (on track)
