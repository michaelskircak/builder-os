# 1:1s · Dev Raman

Newest on top.

---

## 2026-10-21
**His topics:** Confidence cutoff. Data.
**My topics:** Guardrail timing for Nov 5.
**Notes:**
- Guardrail is ~2 days of work, plus a day for Hana on the confirm screen.
- Won't commit to a 0.95 vs 0.97 cutoff until he sees Rafa's export. "If I guess the cutoff I'm doing the same thing the model did."
- For the retrain he needs ~5,000 labeled handwritten tabs. Asked if pilots would share old photos.
**Commitments:**
- [ ] Dev: cutoff recommendation within a day of the export
- [ ] Jules: ask pilots for old handwritten receipt photos

## 2026-10-12
**Notes:**
- Monday after Nashville. He'd already pulled the read log before I got in.
