# 1:1s · Ollie Brandt

Newest on top.

---

## 2026-10-19
**His topics:** "Who's actually holding the phone at the bar at midnight?"
**My topics:** Fri dashboard review prep.
**Notes:**
- He's designed three versions of the trip dashboard and feels like he's designing for Gus, who said he doesn't want a dashboard.
- Wants to shadow a trip host. Told him I'd ask Imani about a wedding weekend.
**Commitments:**
- [ ] Jules: synthesis of the 3 pilot interviews before Fri 2pm
- [ ] Jules: ask Imani about Ollie shadowing
