# Pilot check-in · Wanderpack (Pete) · 2026-10-21

**Who:** Pete Novak, Jules
**Project:** Halvsies Host

## Notes
- **How's it going:** "Fine. Better than the folder of photos."
- **Usage:** trip hosts split everything in the app with review on. Pete uses the dashboard to export at the end.
- **Moment that mattered:** taco truck receipt read as $84 instead of $64. Marco caught it on the review screen.
- **Price reaction:** "Per business, not per trip, or I'm counting trips every month like an idiot." Fine with $49.
- **Renewal odds:** yes.
- **Asks:** finance export with receipt photos attached (third time).

## Commitments
- [ ] Jules: answer on the finance export after pricing (parked in SPRINT.md)
