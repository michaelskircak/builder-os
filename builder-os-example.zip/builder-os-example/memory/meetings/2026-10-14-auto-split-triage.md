# Auto-Split triage · 2026-10-14

**Who:** Dev, Coco, Rafa, Jules
**Project:** Auto-Split v2

## Notes
- Dev walked through the read log (see `projects/auto-split-v2/research/nashville-tab-read-log.md`). Handwritten "1" read as "7". Receipt misclassified as printed.
- Dev: "The model isn't broken. It's read maybe 20,000 handwritten tabs in its life and two million printed ones. That's a data problem pretending to be a model problem."
- Rafa: exact-total on handwritten is 58% (from 10-11 report). Host receipts are 22% hard; consumers 4%. And the model is confidently wrong on them.
- Dev proposed the guardrail: on hard receipts, low confidence, or a share 3x the group's usual, don't send; show the photo with the total circled and make the payer confirm. ~2 days plus Hana.
- Coco: launch is Nov 5 unless someone brings her a reason in writing. "This might be the reason. Jules, bring me a call."
- Open: what confidence cutoff? Dev wants the Host export before picking.

## Decisions
- None final. Launch call owed to Coco.

## Commitments
- [ ] Rafa: export of all Host reads since Sep 8 by type (asked formally 10-19)
- [ ] Dev: handwritten + low-light error analysis once export lands
- [ ] Jules: launch recommendation to Coco
