# Pilot check-in · Big Day Collective (Imani) · 2026-10-20

**Who:** Imani Brooks, Jules
**Project:** Halvsies Host

## Notes
- **How's it going:** "Good. Really good actually." Uses it on every wedding weekend.
- **Usage:** the unpaid list for the current weekend, every day. Multi-trip dashboard: never. Reminders: still off.
- **Moment that mattered:** collected a welcome dinner in 4 days instead of a month. "First time I didn't have to ask anyone's uncle."
- **Price reaction:** "$49 still feels like a lot for a group chat." Would pay annually with a discount. Asked for 2 months free.
- **Renewal odds:** yes, pending the annual discount.
- **Asks:** "My couples' aunts are not downloading an app."

## Decisions
- Annual + 2 months free for pilots → logged as trial in `projects/halvsies-host/decisions.md`, needs Coco

## Commitments
- [ ] Jules: confirm annual discount by Fri 10-23
