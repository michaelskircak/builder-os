# Last Call Co. incident call · 2026-10-11

**Who:** Gus Ferreira, Jules (Bea joined for the first 5 min)
**Projects:** Auto-Split v2, Halvsies Host

## Prep
(No /prep. Called him back within an hour of his email to Bea.)

## Notes
- Gus walked through it: Luis snapped the tab at 11:41pm. Requests went out. Two guys paid $612 before the best man lost it in the group chat.
- "The groom's mom called ME. Not you. Me."
- He's not angry about the money; both refunds went through this morning. He's angry he looked bad to a family that's already referred him twice.
- "I told my guys to trust your app over a napkin. That's on me once. It won't be twice."
- Bea apologized and said Jules would follow up with exactly what happened. Then dropped.
- Gus: "I want to know if this is a handwriting thing or a your-app-is-broken thing."
- Asked him to turn off one-tap send and use the review screen until we follow up. He agreed and told his trip hosts.

## Decisions
- Pilots: one-tap send off, review screen on, until further notice. Told all three by text same day.

## Commitments
- [ ] Jules: written timeline + what we're changing + make-good, by Thu 10-22
- [x] Jules: tell Imani and Pete to use review on every split (done 10-11)
- [x] Jules: 2-line heads-up to Coco (done 10-11, late; Bea told her first)
