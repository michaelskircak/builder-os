source: me, 10-21 on the train

Every pilot has guests who won't install the app. Gus's groomsmen, Imani's aunts, Pete's finance people. What if a guest could pay from a text message link with Apple Pay and never make an account? The planner still sees it in Host. Probably a payments/compliance headache (ask Tomás). Maybe it's the whole product.
