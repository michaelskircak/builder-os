# Decisions · Halvsies Host

Newest on top.

---

## 2026-10-20 · Annual plan discount for pilots
**Call:** Pilots who pay annually get 2 months free (pending Coco's ok)
**Made by:** Jules (proposed), Coco to confirm  **Status:** trial

**Context:** Imani asked for it on the 10-20 check-in. Cash-flow-sensitive small businesses prefer one payment they can plan around.
**Options considered:**
- A. No annual plan until paid launch (simple, risks Imani's yes)
- B. Annual with 2 months free for pilots only (small revenue cost, locks in a year)
- C. Annual with 2 months free for everyone (sets a precedent before we know the price works)
**Why this one:** B. It rewards the people who took a risk on us and doesn't commit the public price.
**What would change our mind:** Coco or Bea want annual as the default for everyone.
**Revisit:** at paid launch, Nov 10
**Who needs to know:** Coco → [ ] told · Imani → [ ] told

---

## 2026-09-22 · Automatic reminders on by default for pilots
**Call:** Reminders go out to unpaid guests at 24h and 72h unless the planner turns them off
**Made by:** Jules  **Status:** decided

**Context:** Hana shipped early. Chasing is the #1 complaint in pilot kickoff calls.
**Options considered:**
- A. Off by default (safer; planners might not find it)
- B. On by default (risk: a planner's VIP client gets an automated nudge)
**Why this one:** B. Chasing is the job we're here to take off their plate.
**What would change our mind:** A planner complains a reminder embarrassed them
**Revisit:** pilot end
**Who needs to know:** Hana, Ollie, pilots → [x] told

---

## 2026-09-02 · Price per business, not per planner seat
**Call:** Pricing unit is the business
**Made by:** Jules + Bea  **Status:** decided

**Context:** Planners have rotating part-time trip hosts. Per-seat pricing would punish them for giving Luis a login.
**Options considered:**
- A. Per seat (SaaS default)
- B. Per business
- C. Per trip
**Why this one:** Bea: "price it like something a small business buys without a meeting."
**What would change our mind:** Big agencies with 40 trip hosts showing up
**Revisit:** paid launch
**Who needs to know:** Rafa, marketing → [x] told
