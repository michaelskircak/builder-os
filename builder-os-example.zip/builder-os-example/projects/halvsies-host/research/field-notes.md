# Field notes · Halvsies Host

Running file. Quotes and observations from check-ins and calls, newest on top. Filed by /debrief.

---

## 2026-10-21 · Pete check-in (call)
- In for paid.
- "Per business, not per trip, or I'm counting trips every month like an idiot."
- Monday's offsite: a taco truck receipt read as $84 instead of $64. Marco caught it on the review screen.
- Asked again for a finance export with receipt photos.

## 2026-10-20 · Imani check-in (call)
- In for paid. Wants annual with 2 months free.
- "My couples' aunts are not downloading an app. I text them a Zelle number and pray."
- Still hasn't turned on automatic reminders. "I don't want a robot texting someone's grandmother."

## 2026-10-11 · Gus incident call (see memory/meetings/2026-10-11-last-call-incident-call.md)
- "I told my guys to trust your app over a napkin. That's on me once. It won't be twice."
- "The groom's mom called ME. Not you. Me."

## 2026-10-08 · Ollie's notes from pilot screenshots
- Gus's Sunday spreadsheet has a column called "CHASE" with 1, 2, or 3 skull emoji.
