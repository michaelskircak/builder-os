# Interview · Pete Novak · 2026-10-06

**Who:** Pete Novak, head of ops, Wanderpack (Austin)
**Why them:** Corporate offsites: bigger groups, expense reports, finance teams in the loop
**Project:** Halvsies Host  **Interviewer:** Jules  **Format:** video call, 1pm CT

## Their world
3 to 5 offsites a month, 20 to 60 people each. Some costs go on the client's corporate card; the rest (dinners out, bar tabs, food trucks) Wanderpack fronts and bills back. Trip hosts on site; Pete back at the office.

## The last time it happened
September offsite, 48 people. Trip host Sam put a $1,900 dinner on his own card "because the restaurant's card machine was down for the company card." Took 5 weeks to get through the client's finance team because nobody could find the receipt photo.

## Workarounds
- A shared spreadsheet per offsite, plus a folder of receipt photos named by date
- The client's finance team gets a PDF at the end. "It takes Sam a full day to build."
- Pete reviews every split before it goes out. Always.

## Quotes worth keeping
> "My people don't Venmo each other. They expense it. They need a PDF, not an app."

> "I still check every split before it sends. Your app's the first draft."

> "The dashboard's fine. I don't need fine. I need finance to stop emailing me."

> "Food trucks write receipts on a notepad. Your thing gets those wrong a lot."

## What surprised me
- Wanderpack never turned on Auto-Split's one-tap send. They use the review screen on every split because finance wants the photo attached.
- The dashboard is useful to Pete for one thing: export at the end of an offsite.

## Assumptions this touches
- Pay $49/business: **supports** (if per business)
- Dashboard is core value: **mixed** (useful for export, not daily)
- Auto-Split accuracy carries over: **weakens** ("gets those wrong a lot" on handwritten)
- Guests will download the app: **weakens** (corporate guests expense; they want a PDF)
