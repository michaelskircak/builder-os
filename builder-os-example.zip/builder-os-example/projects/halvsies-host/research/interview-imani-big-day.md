# Interview · Imani Brooks · 2026-10-01

**Who:** Imani Brooks, owner, Big Day Collective (Jersey City)
**Why them:** Weddings: older, wider guest mix, high stakes for the planner's reputation
**Project:** Halvsies Host  **Interviewer:** Jules  **Format:** in person, her studio

## Their world
4 to 6 wedding weekends a month. Fronts welcome dinners and group activities, collects from guests and sometimes from the couple's parents. Team of 3. Imani runs every weekend herself.

## The last time it happened
In August, a welcome dinner for 40. She fronted $3,100. Collected from 31 guests in a week, the last 9 over a month. "I had to ask the groom's uncle three times. At the wedding. While he was dancing."

## Workarounds
- A Google Sheet, color-coded every Sunday night
- Zelle number texted to guests, plus Venmo for the younger ones
- Asking the couple to "nudge" their own families, which she hates doing

## Quotes worth keeping
> "Wedding guests are 22 to 85. Grandma isn't downloading Halvsies."

> "$49 a month is a lot for a group chat. I know it's not a group chat. But it looks like one."

> "I only care about who hasn't paid. The rest can wait."

> "The split is great. I don't check it anymore, it's always right."

## What surprised me
- She uses one screen: the unpaid list for the current weekend. Never the multi-trip dashboard.
- About half her guests paid her outside the app anyway (Zelle, cash at the wedding), and she logged those by hand.
- She trusts Auto-Split completely. Her receipts are mostly printed restaurant checks.

## Assumptions this touches
- Pay $49/business: **mixed** (will pay with annual discount; sees it as messaging)
- Dashboard is core value: **weakens** (one list, one weekend)
- Auto-Split accuracy carries over: **supports** (on printed receipts)
- Guests will download the app: **weakens** ("Grandma isn't downloading Halvsies")
