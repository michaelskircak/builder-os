# Interview · Gus Ferreira · 2026-09-29

**Who:** Gus Ferreira, owner, Last Call Co. (Nashville)
**Why them:** Biggest pilot by trip volume, high-energy groups, night-heavy spending
**Project:** Halvsies Host  **Interviewer:** Jules (Ollie on the call)  **Format:** video call, 2pm CT

## Their world
~12 weekends a month, 8 to 20 guests each. Gus books and sells; six part-time trip hosts run the weekends on the ground. Luis has run 200+. The planner fronts the deposit, the party bus, and most group dinners and bar tabs, then collects from guests.

## The last time it happened
Before Halvsies: a July bachelorette, 16 guests. Two never paid their share of the boat ($240 each). Gus spent "three Sundays" texting them. One paid in September. The other is "the maid of honor, so I'm eating it."

## Workarounds
- Venmo requests sent one by one, matched to a spreadsheet by hand on Sunday nights
- Trip hosts text him photos of receipts at 1am; he types them in Monday
- A "who still owes" message in the trip's group chat, which he says "makes me the bad guy"

## Quotes worth keeping
> "I don't need another dashboard. I need Kyle to pay me."

> "If this saves me one Sunday of chasing Venmo, it's paid for."

> "Half the groomsmen won't download an app for one weekend. They'll Venmo me and I'll match it at midnight."

> "Luis snaps the tab at the bar. I'm asleep. Whatever your thing does at 1am, it does without me."

> "Honestly the group chat is the system. If your thing could be the group chat, but it actually gets people to pay, I'd love you."

## What surprised me
- He's opened the Host dashboard twice in three weeks. Luis uses the app constantly; Gus checks totals by text.
- He trusts the split more when he can see the receipt photo next to it. "The number I'm not sure about. The picture I believe."

## Assumptions this touches
- Pay $49/business: **supports**
- Dashboard is core value: **weakens** ("I don't need another dashboard")
- Auto-Split accuracy carries over: **neutral** (no problems yet)
- Guests will download the app: **weakens** ("won't download an app for one weekend")
