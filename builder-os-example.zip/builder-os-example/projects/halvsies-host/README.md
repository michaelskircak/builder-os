# Halvsies Host → paid

**Owner:** Jules Adeyemi  **Status:** 🟡 at risk
**Appetite:** pilot Sep 8 to Oct 30; paid launch Nov 10; reassess Dec 31
**Started:** 2026-08-24  **Check-in:** 2026-10-30 (pilot renewals)

## The problem
People who plan group trips for a living front thousands of dollars per weekend: deposits, dinners, a boat, a bar tab. Then they spend Sunday night and most of Monday chasing 14 people for $187 each, matching Venmo payments to names in a spreadsheet. When a guest doesn't pay, the planner eats it or becomes the bad guy with a client's friends.

## Why now
- 3% of Halvsies groups over 10 people are created by the same 2,100 accounts. Planners found us before we found them.
- Bea's network gave us three willing pilots.
- The Series B story needs B2B revenue, and wedding + bachelor season planning for 2027 starts in January.

## What done looks like
- 3 of 3 pilots convert to paid by Oct 30
- 10 paying planners by Dec 31
- Pilot trips keep running through Host (no drift back to Venmo + spreadsheet)

## Assumptions to test
1. **Planners will pay $49/month per business** → test: pilot conversions + reactions to the price
2. **The trip dashboard is the core value**: seeing every trip and who's paid in one place → test: dashboard usage, interview answers
3. **Auto-Split's accuracy on consumer receipts carries over to planners' receipts** → test: exact-total rate on Host trips by receipt type
4. **Guests will download the app to pay** → test: % of guests who install vs. pay some other way

## Kill criteria
- Fewer than 2 of 3 pilots convert
- Fewer than 60% of pilot trips run through Host for two weeks straight

## Not doing
- Booking, itinerary, or vendor management
- Custom contracts or invoicing
- More than 25 planners before January

## People
| Who | Role on this project |
|---|---|
| Jules | PM, owns it |
| Hana | Dashboard + reminders |
| Ollie | Design |
| Dev | Auto-Split (shared with v2 project) |
| Bea | Sponsor, pilot relationships |
| Gus, Imani, Pete | Pilot planners |

## Map of this folder
- `decisions.md`: every call, newest first
- `research/`: pilot interviews and field notes
- `artifacts/v1-scope.md`: current scope (written before the interviews, needs a rewrite)
- `artifacts/pricing-notes.md`: raw thinking for the pricing one-pager
