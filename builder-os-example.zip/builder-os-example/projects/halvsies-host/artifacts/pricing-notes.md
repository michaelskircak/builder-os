# Pricing notes (raw, for Bea's one-pager due 10-26)

- Current proposal: **$49/month per business**
- Gus framing (09-29): "If this saves me one Sunday of chasing Venmo, it's paid for." He runs ~12 trips a month. $49 is noise next to one guest who never pays ($150 to $400).
- Imani (10-01, 10-20): "$49 a month is a lot for a group chat." She thinks of it as messaging, not getting paid. Annual + 2 free months gets her to yes.
- Pete (10-21): per business or he walks. Didn't blink at $49.
- Bea: "like something a small business buys without a meeting." Under $50 is the no-meeting line for most small businesses (her guess, not data).
- Open: take a cut of money collected instead of a flat fee? Rafa thinks 0.5% beats $49 for Gus but not for Imani. Need his model.
- Open: what's the make-good worth to Gus? 3 free months = $147, vs. the $1,224 two guests were overcharged (refunded) and the hit to his reputation.
