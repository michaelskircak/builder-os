# Halvsies Host v1 · scope for paid launch

**Owner:** Jules  **Last updated:** 2026-09-01
> ⚠️ Written before the pilot interviews. Due for a rewrite once the synthesis is done.

## Problem
Planners manage money across many trips and guests with no single view of who's paid.

## Goal
Planners can see every trip's balances at a glance and get paid back faster.

## What's in
| # | Item | Why | Priority |
|---|---|---|---|
| 1 | Dashboard: all trips, total fronted, total collected, who owes | Core value prop | must |
| 2 | Automatic reminders to unpaid guests | Chasing is the pain | must |
| 3 | Auto-Split on every trip expense | Speed for trip hosts | must |
| 4 | Trip templates (bachelor weekend, wedding weekend, offsite) | Faster setup | should |
| 5 | Weekly email summary to the owner | Owner isn't on every trip | should |
| 6 | Finance export (CSV) | Offsite clients expense everything | later |
| 7 | Multiple businesses per account | Agencies | later |

## Out
- Booking, vendors, itineraries
- Native web app for guests (guests use the Halvsies app)

## Open questions
- Does the owner pay, or the trip host? · Jules · pilot interviews
- Does anyone read the weekly email? · Rafa · after 4 weeks
