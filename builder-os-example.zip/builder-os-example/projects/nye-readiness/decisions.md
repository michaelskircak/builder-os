# Decisions · NYE readiness

---

## 2026-10-05 · Feature cutoff Nov 13
**Call:** Nothing new ships after Nov 13 until Jan 4, except fixes
**Made by:** Coco + Jules  **Status:** decided

**Context:** Last year a Dec 2 release broke Android notifications for 3 days.
**Why this one:** Two weeks of buffer before Thanksgiving week. Everyone agreed in the room.
**Revisit:** Jan retro
**Who needs to know:** all of product + eng + support → [x] told
