# NYE readiness

**Owner:** Jules (product side), Tamsin (support side)  **Status:** 🟢 on track
**Appetite:** ongoing, Oct 1 to Jan 3
**Started:** 2026-10-01  **Check-in:** 2026-11-02

## The problem
New Year's Eve is our biggest night: 4x normal receipts, mostly big group tabs, between 10pm and 3am. Last year first-reply time hit 22 hours on Jan 1 and the Android rating dropped to 4.3.

## What done looks like
- Crash-free sessions ≥ 99.5%, Nov 1 to Jan 3
- Median first support reply < 4h, Nov 1 to Jan 3
- No feature launches Thanksgiving week or during code freeze (Dec 14 to Jan 4)

## Assumptions to test
1. Most holiday tickets are bank-linking problems → test: Tamsin tags tickets; updated bank-link flow ships Oct 27
2. Two temp support hires are enough → test: first-reply time in week 1 of November

## Not doing
- New features after Nov 13

## People
| Who | Role |
|---|---|
| Tamsin | Support staffing, macros |
| Hana | Bank-link fixes |
| Jules | Freeze calendar, launch sequencing |
