# Decisions · Auto-Split v2

Newest on top.

---

## 2026-10-02 · Host pilots get Auto-Split beta alongside consumers
**Call:** Host pilots join the beta on Sep 28 with 20,000 consumer beta users, one-tap send on by default
**Made by:** Jules  **Status:** decided

**Context:** Planners' trip hosts are the heaviest splitters we have. Fastest way to learn.
**Options considered:**
- A. Consumers only, planners after launch (safer for pilots)
- B. Pilots included (more signal, more risk to pilot relationships)
**Why this one:** B. Pilots asked for it, and they split dozens of tabs a weekend so data comes in fast.
**What would change our mind:** A pilot's guests get overcharged because of it. *(Happened Oct 10. See the incident runbook.)*
**Revisit:** after the first incident
**Who needs to know:** Bea, pilots → [x] told

---

## 2026-09-14 · Don't auto-assign tip and tax
**Call:** Tip and tax split proportionally by default; never assigned to one person
**Made by:** Dev + Jules  **Status:** decided

**Context:** Early tests assigned the whole tip to whoever ordered the most. People hated it.
**Options considered:**
- A. Auto-assign everything (fastest)
- B. Proportional tip and tax, auto-assign items only
**Why this one:** A split that feels unfair gets edited, and edits kill the point of one tap.
**What would change our mind:** Beta users asking for it
**Revisit:** 60-day beta survey
**Who needs to know:** Coco, Tamsin → [x] told
