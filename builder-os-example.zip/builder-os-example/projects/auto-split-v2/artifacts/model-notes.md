# Model notes · Dev Raman

Last updated 2026-10-14. Plain-language version for Jules.

## How it works
The photo goes through a text-recognition step, then a model that understands receipt layout (items, subtotal, tax, tip, total) and checks that the numbers add up. Auto-Split then assigns items using the group's past orders and sends.

## What's wrong
Trained on ~2.1M receipts, ~1% handwritten. On handwritten tabs it gets the total wrong 42% of the time and is still fairly confident (median 0.86). The "do the numbers add up" check didn't fire in Nashville because the items on the tab were mostly illegible, so it trusted the total line.

## Options (my view)
1. **Guardrail (2 days, + 1 day for Hana on the UI):** if the receipt looks handwritten, faded, or low-light, *or* confidence is under 0.95, *or* anyone's share is more than 3x the group's usual spend, don't send. Show the photo with the total circled: "We read $7,140.00. Is that right?" One tap to confirm or fix. Clean printed receipts still send in one tap.
2. **Retrain with real handwritten tabs (3 to 4 weeks):** need ~5,000 labeled handwritten tabs. Pilots could help. Wouldn't be ready by Nov 5.
3. **Show the top two readings (1 week):** "$1,140 or $7,140?" Honest, but people will pick fast at 1am, and it looks broken.

My recommendation: 1 now, 2 for January. I'd skip 3.
