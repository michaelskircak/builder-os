# Read quality by receipt type · week ending 2026-10-11

**From:** Rafa Lim  **Source:** Amplitude "Auto-Split Beta" + confirmed totals, 20,000 consumer + 3 Host pilots
**Caveat from Rafa:** Handwritten sample is small (n=2,140 reads) and 38% of it comes from Last Call Co. Treat that row as directional.

| Receipt type | Reads | Exact total | Median confidence |
|---|---|---|---|
| Printed, clean | 182,400 | 97% | 0.98 |
| Printed, faded or crumpled | 21,300 | 89% | 0.91 |
| Low light (est.) | 6,900 | 71% | 0.83 |
| Handwritten tab | 2,140 | 58% | 0.86 |
| **All** | **212,740** | **95%** | **0.97** |

**Rafa's notes:**
- The model is confidently wrong on handwritten tabs: median confidence 0.86 even though it gets 42% of them wrong. Confidence alone won't catch these.
- 4% of consumer receipts are hard (faded, low light, handwritten). For Host pilots it's 22%: bars, food trucks, small places, at night.
- Bad-send rate: 0.4% consumers, 3.1% Host pilots.
- Consumer beta sentiment: 4.6/5 for one-tap send.
