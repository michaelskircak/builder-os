# Last Call Co. trip "Kyle's Last Rodeo" · Sat Oct 10 to Sun Oct 11

**From:** Dev Raman, pulled 2026-10-12 from read logs + payments

| Time (CT) | What happened |
|---|---|
| 23:41 | Luis (trip host) photographs the tab at a BBQ bar. Handwritten, under string lights. |
| 23:41 | Model reads total as **$7,140.00**. Confidence 0.87. Receipt classified "printed" (wrong). |
| 23:41 | Auto-Split assigns items, adds 20% tip: $8,568. 14 people → **$612 each**. |
| 23:42 | One tap. Requests sent to 13 guests. |
| 23:43 | Guest 1 pays $612 (saved card) |
| 23:46 | Guest 2 pays $612 (saved card) |
| 23:58 | Best man replies in the trip's group chat: "$612 FOR BRISKET??" |
| 00:20 | Luis cancels the remaining 11 requests |
| Sun 08:10 | Best man posts TikTok: "this app tried to charge us $8,500 for brisket" |
| Sun 09:30 | Groom's mother calls Gus |
| Sun 10:05 | Two refunds issued by Tamsin's team ($1,224 total) |

**Actual tab:** $1,140.00. With 20% tip, $1,368, or $97.71 each.
**What went wrong:** the handwritten "1" had a long serif and read as a "7". The model also misclassified the receipt as printed, so no handwritten-receipt caution applied.

**Dev's note:** our training set has ~1% handwritten receipts. The model has seen very few handwritten 1s with serifs.
