# Auto-Split v2

**Owner:** Jules Adeyemi (product), Dev Raman (model)  **Status:** 🔴 off track
**Appetite:** 8 weeks of Dev's time, Sep 14 to Nov 5
**Started:** 2026-09-14  **Check-in:** 2026-10-23 (launch call due to Coco)

## The problem
Snap Split (v1) reads the receipt, but you still tap who had what and review every amount before anything sends. For a 4-person dinner that's fine. For a 14-person bar tab at 1am, the person who fronted the money gives up and says "just split it evenly," and the guy who had one beer pays for someone else's bottle service.

## Why now
- #1 feature request in the app (2,300 votes): "just do it for me"
- Friendsgiving and New Year's Eve are our two biggest nights. One-tap splitting matters most at the end of a long night.
- Host planners' trip hosts split dozens of tabs a weekend. Review on every one doesn't scale.

## What done looks like
- Public launch Nov 5 to all users
- **98% exact-total reads on every receipt type**, not just clean printed ones
- Nobody gets overcharged because of a bad read

## Assumptions to test
1. **A model trained mostly on printed receipts handles every receipt people actually split** → test: exact-total rate by receipt type in the beta
2. **People are comfortable sending requests without reviewing them** → test: % of beta users who turn one-tap off
3. **Auto-assigning items from group history is right often enough** → test: edit rate after send

## Kill criteria
- Can't get above 95% exact-total on clean printed receipts (we're at 97%, so no)
- A second group gets overcharged by a bad read

## Not doing
- Itemized auto-assign for groups over 20 (v3)
- Non-USD receipts until 2027

## People
| Who | Role on this project |
|---|---|
| Dev | Model, guardrail |
| Rafa | Read-quality reporting |
| Tamsin | User-facing wording, macros |
| Coco | Launch date owner |
| Jules | PM |

## Map of this folder
- `decisions.md`: calls so far
- `research/read-quality-2026-10-11.md`: Rafa's exact-total rate by receipt type
- `research/nashville-tab-read-log.md`: what the model saw and did on Oct 10
- `artifacts/model-notes.md`: Dev's notes and the guardrail idea
