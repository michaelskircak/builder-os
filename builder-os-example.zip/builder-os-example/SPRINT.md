# Sprint · week of 2026-10-19

**Focus:** Get Last Call Co. to yes, and make the Auto-Split launch call before Coco has to make it for me.

## Commitments
- [ ] Send Gus the written incident timeline + make-good offer · for Gus · **due Thu 10-22** (promised 10-12)
- [ ] Decide Auto-Split v2 launch plan (ship / delay / guardrail) · for Coco · **due Fri 10-23**
- [ ] Synthesize the 3 pilot interviews before Ollie's dashboard review · for Ollie · due Fri 10-23
- [ ] Weekly update · for Coco, Bea, team · due Fri 10-23
- [ ] Host pricing one-pager · for Bea · due Mon 10-26
- [x] Pilot check-in with Imani · done 10-20
- [x] Pilot check-in with Pete · done 10-21

## Waiting on
- **Rafa:** every Host receipt read since Sep 8, tagged by receipt type, with confidence scores · asked 10-19 · 3 days
- **Dev:** error analysis on handwritten + low-light reads · asked 10-14 · 6 days · blocked on Rafa's export
- **Hana:** rough estimate for pay-by-link (guests pay without the app) · asked 10-20 · 2 days
- **Tamsin:** tickets since Oct 1 mentioning "wrong amount", "overcharged", or "didn't order that" · asked 10-20 · 2 days

## Parked (not this week, on purpose)
- Text-link payments idea (see `inbox/2026-10-21-pay-by-text-idea.md`)
- Wanderpack wants a finance export with receipt photos attached; revisit after pricing
