# Builder OS · Jules Adeyemi

I'm **Jules Adeyemi**, Lead PM at **Halvsies** (Brooklyn, 41 people). Halvsies is a bill-splitting app: snap a receipt, AI reads it, everyone gets a payment request. I own **Halvsies Host** (the paid product for group-trip planners) and **Auto-Split v2** (the AI that reads and splits receipts in one tap). I report to **Coco Delgado**, Head of Product.

## Where things live
- `MISSION.md`: what I own, this quarter's projects, my team at a glance
- `SPRINT.md`: this week. Commitments, waiting-on, parked. `BACKLOG.md`: everything else
- `projects/`: one folder per initiative. Start at its `README.md`; calls go in `decisions.md`
- `team/`: one file per person I work with: teammates, execs, customers
- `memory/`: `daily/`, `meetings/`, `1on1s/`, `done/`
- `runbooks/`: repeatable multi-step work, each with its own `CLAUDE.md`
- `context/`: company, product, customers, glossary, metrics, and `voice.md` (how I write)
- `templates/`: starting points for new files. `inbox/`: dump anything
- `CONFIG.md`: what's connected + conventions. `CHANGELOG.md`: how this OS has changed

## Commands
| Command | Does |
|---|---|
| `/brief` | Morning brief: calendar + sprint + projects + team |
| `/prep <person>` | Meeting prep in that person's preferred format |
| `/debrief` | Paste notes → files commitments, quotes, decisions |
| `/eod` | End of day: update the sprint, log it, set up tomorrow |
| `/new-project <name>` | Start a new project folder |
| `/research <project>` | Turn raw research into findings with quotes and counts |
| `/decide <question>` | Write a decision record into the project |
| `/capture` · `/capture sort` | Dump to inbox · route the inbox |
| `/weekly` | Weekly update runbook, one step at a time |
| `/polish <file>` | Make a draft sound like me |
| `/cleanup` | Weekly cleanup |
| `/incident` | Customer incident runbook |
| `/new-skill` | Turn repeat work into a new command |
| `/onboard` | Interview-based setup (re-run a section any time) |

## House rules
- **Demo clock:** this example is frozen at Thursday 2026-10-22, 8:30am. Treat that as today, whatever the system date says.
- Never invent quotes, numbers, or dates. If it isn't in a file, say so.
- Dates are `YYYY-MM-DD`. File names are `kebab-case`.
- When you learn something lasting about a person, offer to add it to their team file.
- Anything I'll send to another human goes through `context/voice.md`.
