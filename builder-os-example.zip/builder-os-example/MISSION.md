# Mission · Jules Adeyemi

## Me
- **Role:** Lead Product Manager, Halvsies (since March 2025)
- **Own:** Halvsies Host (paid product for group-trip planners, new this year) and Auto-Split (the AI that reads a receipt and splits it)
- **Report to:** Coco Delgado, Head of Product
- **Team:** Dev Raman (ML), Hana Kowalski (mobile + backend), Ollie Brandt (design), Rafa Lim (data, shared with Growth)

**What I'm for, in one line:** make Halvsies something a planner would be upset to lose.

## Q4 2026: what a win looks like
Host is a real paid product with planners who chose to pay, and Auto-Split is good enough that nobody gets overcharged because of us. We get through Friendsgiving and New Year's Eve without a support meltdown.

## Projects

| Project | Target | Status | Now |
|---|---|---|---|
| [Halvsies Host → paid](projects/halvsies-host/README.md) | 3 of 3 pilots convert by Oct 30 · 10 paying planners by Dec 31 | 🟡 | Big Day + Wanderpack say yes. Last Call Co. undecided after the Nashville tab. |
| [Auto-Split v2](projects/auto-split-v2/README.md) | Public launch Nov 5 · 98% exact-total reads on every receipt type | 🔴 | 97% on clean printed receipts. 58% on handwritten tabs. Launch plan undecided. |
| [NYE readiness](projects/nye-readiness/README.md) | 99.5% crash-free · first support reply < 4h, Nov 1 to Jan 3 | 🟢 | Crash-free at 99.7%. Two temp support hires start Nov 2. |

Status key: 🟢 on track · 🟡 at risk · 🔴 off track · ⚪ not started

## Not doing this quarter
- No Halvsies card or wallet features (2027)
- No international currencies
- No AI chat assistant, however many times it comes up in all-hands

## Metrics I watch
- **Monthly active splitters:** 2.3M
- **Exact-total rate** (receipts where the AI's total matches the real one): see `context/metrics.md`
- **Host trips active:** 27 across 3 pilots
- **Support first-reply time:** 2h 40m median (Oct)

## Team at a glance

| Person | Role | Why they matter to me |
|---|---|---|
| [Coco Delgado](team/coco-delgado.md) | Head of Product, my manager | Owns my priorities; hates surprises |
| [Bea Lund](team/bea-lund.md) | CEO, cofounder | Ex-bartender. Host was her idea |
| [Dev Raman](team/dev-raman.md) | ML engineer | Owns the receipt-reading model |
| [Hana Kowalski](team/hana-kowalski.md) | Mobile + backend eng | Building the Host dashboard |
| [Ollie Brandt](team/ollie-brandt.md) | Product designer | Host UX |
| [Rafa Lim](team/rafa-lim.md) | Data analyst | Every number I quote comes from Rafa |
| [Tamsin Reyes](team/tamsin-reyes.md) | Support lead | Front line for 2.3M users |
| [Gus Ferreira](team/gus-ferreira.md) | Owner, Last Call Co. (pilot) | His trip got the $7,140 tab |
| [Imani Brooks](team/imani-brooks.md) | Owner, Big Day Collective (pilot) | Our happiest pilot |
| [Pete Novak](team/pete-novak.md) | Head of ops, Wanderpack (pilot) | Team offsites. Blunt. |
