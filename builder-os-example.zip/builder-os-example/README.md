# Builder OS · Example

A fully loaded Builder OS for a fictional builder, so you can see how the pieces connect before you set up your own.

**Meet Jules Adeyemi**, Lead PM at **Halvsies**, a 41-person startup in Brooklyn. Halvsies is a bill-splitting app with 2.3 million monthly users. Snap a receipt and an AI model reads it, splits it, and sends everyone a payment request. Jules is turning it into a paid product for group-trip planners.

It's **Thursday, October 22, 2026, 8:30am**. Twelve days ago, the new Auto-Split feature misread a handwritten bar tab in Nashville as **$7,140 instead of $1,140** and sent 13 groomsmen a $612 payment request each. Two of them paid before anyone noticed. The best man's TikTok about it has 1.4 million views. The trip was run by Last Call Co., one of Jules's three paying pilots, and their renewal decision is October 30.

Everything in this folder is how Jules's week looks right before she opens Claude Code.

## Replay Jules's Thursday

Open this folder in Claude Code and run these in order:

```
/brief
/prep gus-ferreira
/debrief            ← paste the sample notes at the bottom of this file
/decide should Auto-Split v2 launch on Nov 5?
/research halvsies-host
/weekly
/polish runbooks/weekly-update/drafts/<this week>/draft.md
/new-skill scan
/eod
```

No calendar or tracker connection needed. Every command falls back to the files. (Today's fake calendar lives in `memory/daily/2026-10-22.md`.)

## Sample notes for /debrief (from the 11:00 call with Gus)

```
gus call 11am. way calmer than last wk. read the timeline, said "ok so its a handwriting thing not a your app is broken thing" lol
- derek (best man) posted a follow up saying we refunded in 10 hrs. comments are nicer now
- he wants: the receipt photo with the number circled before anything sends. "dont tell me $612 show me the receipt"
- his trip hosts (luis etc) do all the snapping. half the guests never open the app, they just want a link to pay. !!! guests-wont-download thing again
- make-good: he liked the 3 free months. didnt want account credit, "keep your credit, fix the handwriting thing"
- renewal: "if the handwriting thing is fixed before my new years trips im in." first NYE trip leaves dec 29
- asked if he can talk to dev directly about the model
- me: send him the fix plan in writing by tues oct 27
- he'll send me photos of ~40 handwritten tabs from past trips so dev can test on them
```
